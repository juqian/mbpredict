package test.experiment;

import java.io.File;

import org.junit.Test;
/**
 * 这里用来运行脚本
 * @author zhouxu
 *
 */
public class RecordCollector {
	static String ScriptFolder = "../test_script";
	static boolean DEBUG = false;
	static int TIMES = 1;
	
	public void runScripts(String app, String[] scriptNames, int times) throws Exception{ 
		String[] scriptpaths = new String[scriptNames.length];
		for(int i = 0; i < scriptNames.length;i++){
			File path = new File(ScriptFolder, app);
			path = new File(path, scriptNames[i]);
            scriptpaths[i] = path.getCanonicalPath(); 
        }
		
		ScriptRunner.runTestScripts(scriptpaths, times, !DEBUG);
	}
	
	 
	@Test
	public void startTomcat() throws Exception{
		Tomcat.startTomcat(); 
		while(true){
			Thread.sleep(10000);
		}
	}
		
	@Test
	public void shutdownTomcat() throws Exception{ 
		Tomcat.shutdownTomcat();
	}		
		
	
	/*
	 * Jtrac
	 */
	@Test
	public void scriptRunTestJtrac() throws Exception{
		String[] scripts = {"manage_user.py"};
		runScripts("jtrac", scripts, TIMES);
	}
 
	@Test
	public void scriptRunTestVQWiki() throws Exception{
		String[] scripts = {"add_task.py"};
		runScripts("VQWiki", scripts, TIMES);
	}
 
	@Test
	public void scriptRunTestMeshcms() throws Exception{
		//String[] scripts = {"change_title.py"};
		//String[] scripts = {"clean_html.py"};
		//String[] scripts = {"config_site.py"};
		//String[] scripts = {"edit_html_preview.py"};
		//String[] scripts = {"edit_html_save.py"};
		//String[] scripts = {"export.py"};
		//String[] scripts = {"file_manage.py"};
		//String[] scripts = {"new_child_page.py"};
		//String[] scripts = {"page_manager.py"};
		String[] scripts = {"refresh_site_map.py"}; 
		
		runScripts("meshcms", scripts, TIMES);
	}
 
	@Test
	public void scriptRunTestJert() throws Exception{
		String[] scripts = {"reset_password.py"};
		runScripts("jert", scripts, TIMES);
	}
 
	@Test
	public void scriptRunTestYawebmail() throws Exception{
		String[] scripts = {"send_email_with_pdf.py"};
		runScripts("yawebmail", scripts, TIMES);
	}
 
	@Test 
	public void scriptRunTestSolo() throws Exception{
		String[] scripts = {"add_url.py"};
		runScripts("solo", scripts, TIMES);
	}

	@Test
	public void scriptRunTestJenkins() throws Exception{
		//String[] scripts = {"about_jenkins.py"};
		//String[] scripts = {"refresh_status.py"};
		//String[] scripts = {"script_console.py"}; 
		//String[] scripts = {"system_props.py"};
		//String[] scripts = {"cli_usage.py"};
		//String[] scripts = {"auto_refresh.py"}; 
		//String[] scripts = {"people_admin.py"};
		//String[] scripts = {"old_data.py"}; 
		//String[] scripts = {"build_history.py"}; 
		String[] scripts = {"export_xml.py"};		
		runScripts("jenkins", scripts, TIMES);
	}
 
	@Test
	public void scriptRunTestContineo() throws Exception{
		String[] scripts = {"create_message_test.py"}; 
		runScripts("contineo", scripts, TIMES);
	}
 
	@Test
	public void scriptRunTestJforum() throws Exception{
		//String[] scripts = {"downloads.py"};  
		//String[] scripts = {"forum_index.py"};  
		//String[] scripts = {"hottest_topics.py"};  
		//String[] scripts = {"members.py"};  
		//String[] scripts = {"moderation_log.py"}; 
		//String[] scripts = {"recent_topics.py"};  		
		//String[] scripts = {"search.py"};  
		//String[] scripts = {"new_topic.py"};  
		//String[] scripts = {"manage_options.py"};  
		String[] scripts = {"lost_password.py"};  
		runScripts("jforum", scripts, TIMES);
	}
}

	
