package test.experiment;

import java.io.File; 
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
  

import net.sf.json.JSONObject;

import org.junit.Test;

import com.memtest.core.TestScript;
import com.memtest.test.JmxWebContainerConnector;
import com.memtest.test.MemoryState;
import com.memtest.test.TestRecord;
import com.memtest.util.CmdRunner;
import com.memtest.util.Utils;


/**
 * 运行测试脚本，收集基本数据
 *
 */
public class ScriptRunner {
	static final String RECORD_FOLDER = "output/records";
	
	// 运行1个轮次
	@Test
	public void runTestScript1Round() throws Exception {
		String[] scripts = {"test/data/WorkSpace/Project1/Test2-showcase/showcase_back.py"}; 
		runTestScripts(scripts, 1, true); 
	}	
	
	// 运行10个轮次
	@Test
	public void runTestScript10Round() throws Exception {
		String[] scripts = {"test/data/WorkSpace/Project1/Test2-showcase/showcase_back.py"}; 
		runTestScripts(scripts, 10, true); 
	}
	
	// 运行500个轮次
	@Test
	public void runTestScript500Round() throws Exception {
		String[] scripts = {"test/data/WorkSpace/Project1/Test2-showcase/showcase_back.py"}; 
		runTestScripts(scripts, 500, true); 
	}
	
	/**
	 * 批量运行测试脚本. 运行完成后将记录写到文件中
	 */
	public static List<TestRecord> runTestScripts(String[] scripts, int times, boolean ctrlTomcat) throws Exception{
		List<TestRecord> records = new ArrayList<TestRecord>();
		for(String script: scripts){
			File scriptFile = new File(script);
			TestRecord record = runTestScript(scriptFile, times, ctrlTomcat);
			records.add(record);
		}
		
		return records;
	}
	
 
	/**
	 * 运行单个测试脚本。运行完成后将记录写到文件中
	 */
	public static TestRecord runTestScript(File script, int times, boolean ctrlTomcat) throws Exception {
		if(!script.exists()){ 
			throw new Exception("Script not exist: " + script);
		}
		
		String scriptPath = script.getAbsolutePath();
		
		if(ctrlTomcat){
			Tomcat.startTomcat();
			Thread.sleep(5000);

			//Thread.sleep(20000);
			
			// warm up
			for (int i = 0; i <2 ; i++) { 
				runScript(scriptPath); 
			}
			
			Thread.sleep(5000);
		}
		
			
		// 启动数据采集跟踪
		JmxWebContainerConnector jmx = new JmxWebContainerConnector();
		jmx.startProfiling(false);
		
		MemoryState oldState = jmx.getMemoryState();
				
		//开始执行时间
		Date start = new Date();
		//循环运行脚本
		for (int i = 0; i <times ; i++) { 
			runScript(scriptPath);
			System.out.println("脚本运行轮数      "+(i+1));
		}
		//运行结束时间
		Date end = new Date();
		
		// 强制进行一次垃圾收集
		jmx.forceGC();		
		
		//获取内存状态
		//此处使用的内存改成：脚本执行后使用的内存 - 脚本执行前使用的内存。因为总的使用内存本身受Tomcat影响，采集的意义不大
		MemoryState newState = jmx.getMemoryState();
		long usedMemory = newState.getUsedMemory() - oldState.getUsedMemory();
		newState.setUsedMemory(usedMemory); 
		 
		List<MemoryState> ms = new ArrayList<MemoryState>();
		ms.add(newState); 
	 
		TestRecord testRecord = new TestRecord(TestRecord.createID(), ms, start, end); 
		String webappName = script.getParentFile().getName(); 
		testRecord.setScriptName(webappName + File.separator + script.getName());
		testRecord.setBloatWeight(0.0);
		
		saveTestRecord(script, times, end, testRecord);
		
		if(ctrlTomcat){
			// 杀死Tomcat进程。每次重新启动，避免脚本执行之间的干扰
			Thread.sleep(2000);
			Tomcat.shutdownTomcat();
		} 
		
		return testRecord;
	}
	
	
	public static void saveTestRecord(File script, int times, Date testTime, TestRecord testRecord) throws IOException{
		String webappName = script.getParentFile().getName();
		File scriptRecordFolder = new File(RECORD_FOLDER, webappName + File.separator + times);
		if(!scriptRecordFolder.exists()){
			scriptRecordFolder.mkdirs();
		}
		
		String recordFileName = getRecordFileName(script, times, testTime);
		File recordFile = new File(scriptRecordFolder, recordFileName);
		JSONObject json = testRecord.toFileJSON();		
		Utils.saveTextToFile(json.toString(), recordFile.getCanonicalPath());		
	}
	
	
	public static String getRecordFileName(File script, int times, Date testTime){
		String scriptName = script.getName();
		scriptName = scriptName.substring(0, scriptName.length()-3); 
		
		DateFormat fmt =new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		String time = fmt.format(testTime);
		
		return scriptName + "." + time + ".record";
	}
	

	public static void runScript(String fileName) {		
		File file = new File(fileName);
		TestScript script = new TestScript(file);
		String scriptPath = script.getScriptFile().toString();

		try {
			File fpythonHome = new File(".\\python");
			String pythonHome = fpythonHome.getCanonicalPath();

			String cmd = "\"" + pythonHome + "\\python.exe\" " + "\""
					+ scriptPath + "\"";
			String pyPath = "\"" + pythonHome + "\\DLLs;" + pythonHome
					+ "\\Lib;" + pythonHome + "\\Lib\\site-packages" + "\"";

			Map<String, String> env = new HashMap<String, String>();
			env.put("PYTHONPATH", pyPath);
			env.put("PYTHONHOME", pythonHome);

			CmdRunner.runCommand(pythonHome, env,
					Collections.singletonList(cmd), true);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}
}
