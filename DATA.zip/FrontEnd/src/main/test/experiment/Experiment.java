package test.experiment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays; 
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List; 
import java.util.Map;

import org.junit.Test;

import test.experiment.TrainAndPredict.PredictResult;

import com.memtest.test.TestRecord;
/**
 * 
 * 直接在这里运行就可以获得最终的.csv记录
 * @author zhouxu 
 */

public class Experiment { 
	static final String RECORD_FOLDER = "../records";
	static final String TRAIN_FOLDER = "output/train";
	static final String MODEL_FILE = "output/train/test.model";
	
	static final int LARGE_ROUNDS = 500; 
	static String[] WEBAPPS = { "vqwiki", "meshcms", "jenkins", "contineo", "yawebmail", "jforum", "jert", "solo","jtrac"};
	
	
	@Test
	public void test() throws Exception{ 
		crossValidation(WEBAPPS, 7);
	} 
	
	public static void crossValidation(String[] webapps, int trainedAppCount) throws Exception{	
		List<List<String>> trainedGroups = new ArrayList<>();
		findTrainGroups(0, trainedAppCount, webapps, new ArrayList<String>(), trainedGroups);
		
		List<PredictResult> results = new ArrayList<>();
		int i = 1;
		for(List<String> trainGroup: trainedGroups){ 
			System.out.println("[" + String.format("%02d", i) + "] trained Apps： " + trainGroup); 
			trainAndPredict(webapps, trainGroup, results);
			i++;
		}   
		
		writeResults(results);
	}
	
	static void trainAndPredict(String[] webapps, List<String> trainedApps, List<PredictResult> results) throws Exception{ 
    	List<String> testApps = new ArrayList<String>(Arrays.asList(webapps)); 
    	testApps.removeAll(trainedApps);
    	
    	
    	
		TrainAndPredict.trainModel(RECORD_FOLDER, TRAIN_FOLDER, LARGE_ROUNDS, trainedApps); 
		File modelFile = new File(TRAIN_FOLDER, "test.model");
		
		for (String s : testApps) {
			TrainAndPredict.doPrediction(s, RECORD_FOLDER, LARGE_ROUNDS, TRAIN_FOLDER, modelFile, results);
		}
	}
	
	static void writeResults(List<PredictResult> results) throws IOException{ 
		saveNDCGs(results);
		savePredictOrderPosStat(results);
		saveUseMemOrderPosStat(results);
		calcTestAcceleration(results);
		saveAppRandOrders(results);
	} 
	
	static void saveAppRandOrders(List<PredictResult> results) throws IOException{    
		ArrayList<String> apps = new ArrayList<>(Arrays.asList(WEBAPPS));
		Collections.sort(apps);
		
		Map<String, List<PredictResult>> appToResults = new LinkedHashMap<>();
		for(String app: apps){ 
			List<PredictResult> appResults = new ArrayList<>();
			appToResults.put(app, appResults);
		}
		
		for(PredictResult rs: results){ 
			String app = rs.app;
			List<PredictResult> appResults = appToResults.get(app);
			appResults.add(rs);
		} 
		
		BufferedWriter bf =  new BufferedWriter(new FileWriter(new File("rank_orders.txt"), false)); 
		
		for(Map.Entry<String, List<PredictResult>> e: appToResults.entrySet()){
			String app = e.getKey(); 
			List<PredictResult> appResults = e.getValue();  
 
			int useMemOrder = appResults.get(0).bloatScriptOrderInUsedMem;
			
			String predictOrders = "";
			for(PredictResult rs: appResults){
				int predictOrder = rs.bloatScriptOrderInPredict; 
 
				if(predictOrders.length()>0){
					predictOrders += ", ";
				}				
				predictOrders += predictOrder; 
			}  

			bf.write(app + " mem_order="+useMemOrder +", predict_orders: " + predictOrders +"\r\n");   
		} 
		
		bf.close(); 
	} 
	
	
	static void calcTestAcceleration(List<PredictResult> results) throws IOException{    
		ArrayList<String> apps = new ArrayList<>(Arrays.asList(WEBAPPS));
		Collections.sort(apps);
		
		Map<String, List<PredictResult>> appToResults = new LinkedHashMap<>();
		for(String app: apps){ 
			List<PredictResult> appResults = new ArrayList<>();
			appToResults.put(app, appResults);
		}
		
		for(PredictResult rs: results){ 
			String app = rs.app;
			List<PredictResult> appResults = appToResults.get(app);
			appResults.add(rs);
		}
		
		// time demanded to reveal bloat
		String lineUnprioritized = "";
		String lineOrderByUseMem = "";
		String lineOrderByPredict = "";
		
		long totalTimeUnprioritized = 0;
		long totalTimeUseMem = 0;
		long totalTimePredict = 0;
		
		for(Map.Entry<String, List<PredictResult>> e: appToResults.entrySet()){
			List<PredictResult> appResults = e.getValue(); 
			
			//Unprioritized: time = the sum of the time to run 5 scripts for a large scale (500 rounds). 
			long timeUnprioritized = 0;
			{
				Map<String, Long> longRunTime = appResults.get(0).longRunTime;
				long totalTime = 0;
				for(Map.Entry<String, Long> t: longRunTime.entrySet()){
					totalTime += t.getValue();
				}
				timeUnprioritized = totalTime/2;
				totalTimeUnprioritized += timeUnprioritized;
				
				if(lineUnprioritized.length()>0){
					lineUnprioritized += ", ";
				}
				lineUnprioritized += (timeUnprioritized/1000);  //seconds
			} 
			
			// rank by used memory: time = the time to run all the scripts (10 scripts) for one round to collect feature data
			//         + the time to run those test scripts incorrectly ranked before the really bloat-inducing script for a large number of rounds
            //         + the time to repeatedly run the real bloat-inducing script to observe the bloat. 
			{
				PredictResult rs = appResults.get(0);
				List<TestRecord> rankedRecords = rs.rankedByUsedMem;
				
				long appTotalTime = 0; 
				long featureCollectionTime = 0;
				for(TestRecord record: rankedRecords){
					featureCollectionTime += record.getElapsedTime();
				}				
				appTotalTime += featureCollectionTime; 
				
				long testExecTime = 0;
				for(int i=0; i<rs.bloatScriptOrderInUsedMem; i++){
					TestRecord record = rankedRecords.get(i);
					String script = record.getScriptName();
					long scriptLongRunTime = rs.longRunTime.get(script);
					testExecTime += scriptLongRunTime;
				}
				
				appTotalTime += testExecTime; 
				
				if(lineOrderByUseMem.length()>0){
					lineOrderByUseMem += ", ";
				}
				lineOrderByUseMem += (appTotalTime/1000);  //seconds
				
				totalTimeUseMem += appTotalTime;
			} 
			
			//Prioritized: time = the time to run all the scripts (10 scripts) for one round to collect feature data
			//         + the bloat prediction time 
			//         + the time to run those test scripts incorrectly ranked before the really bloat-inducing script for a large number of rounds
            //         + the time to repeatedly run the real bloat-inducing script to observe the bloat. 
			long sumOfAppTotalTime = 0;
			for(PredictResult rs: appResults){
				List<TestRecord> rankedRecords = rs.rankedByPredict;
				
				long appTotalTime = 0; 
				long featureCollectionTime = 0;
				for(TestRecord record: rankedRecords){
					featureCollectionTime += record.getElapsedTime();
				}				
				appTotalTime += featureCollectionTime;
				
				appTotalTime += rs.predictTime;
				
				long testExecTime = 0;
				for(int i=0; i<rs.bloatScriptOrderInPredict; i++){
					TestRecord record = rankedRecords.get(i);
					String script = record.getScriptName();
					long scriptLongRunTime = rs.longRunTime.get(script);
					testExecTime += scriptLongRunTime;
				}
				
				appTotalTime += testExecTime;
				
				sumOfAppTotalTime += appTotalTime;
			}
			// average of multiple prediction
			long prioritizedTime = sumOfAppTotalTime/appResults.size();
			totalTimePredict += prioritizedTime;
			
			if(lineOrderByPredict.length()>0){
				lineOrderByPredict += ", ";
			}
			lineOrderByPredict += (prioritizedTime/1000);  //seconds
		}
		
		BufferedWriter bf =  new BufferedWriter(new FileWriter(new File("accelerate.txt"), false)); 
		bf.write("y1=["+lineUnprioritized +"]\r\n");  
		bf.write("y2=["+lineOrderByPredict +"]\r\n");  
		bf.write("y3=["+lineOrderByUseMem +"]\r\n");  
		
		bf.write("accelerate_to_unprioritized="+ (100.0*(double)(totalTimeUnprioritized-totalTimePredict)/totalTimeUnprioritized) +"%\r\n");  
		bf.write("accelerate_to_use_mem="+ (100.0*(double)(totalTimeUseMem-totalTimePredict)/totalTimeUseMem) +"%\r\n");  
		bf.write("accelerate_to_use_mem_to_unprioritized="+ (100.0*(double)(totalTimeUnprioritized-totalTimeUseMem)/totalTimeUnprioritized) +"%\r\n");  
		bf.close(); 
	} 
	
	
	static void savePredictOrderPosStat(List<PredictResult> results) throws IOException{   
		Map<Integer, Integer> orderAtPosCount = new HashMap<>();
		for(int i=1; i<=10; i++){
			orderAtPosCount.put(i, 0);	
		}
		
		for(PredictResult rs: results){ 
			Integer count = orderAtPosCount.get(rs.bloatScriptOrderInPredict);  
			orderAtPosCount.put(rs.bloatScriptOrderInPredict, count + 1);			
		}
		
		saveOrderPosStat("predict_order_stat.txt", orderAtPosCount, results.size());
	} 
	
	
	static void saveUseMemOrderPosStat(List<PredictResult> results) throws IOException{ 
		Map<Integer, Integer> orderAtPosCount = new HashMap<>();
		for(int i=1; i<=10; i++){
			orderAtPosCount.put(i, 0);	
		}
		
		for(PredictResult rs: results){ 
			Integer count = orderAtPosCount.get(rs.bloatScriptOrderInUsedMem); 
			orderAtPosCount.put(rs.bloatScriptOrderInUsedMem, count + 1);			
		}
		
		saveOrderPosStat("use_mem_order_stat.txt", orderAtPosCount, results.size()); 
	} 
	
	
	static void saveOrderPosStat(String file, Map<Integer, Integer> orrderAtPosCount, int totalTests) throws IOException{   
		DecimalFormat df = new DecimalFormat("#00.0");  
		String accumulateLabel = "";
		String accumulatePercentLabel = "";
		String atPosLabel = "";		
		for(int i=1; i<=10; i++){
			int orderAt = orrderAtPosCount.get(i);	
			int orderAtAndBefore = 0;
			for(int k=1; k<=i; k++){
				int count = orrderAtPosCount.get(k);
				orderAtAndBefore += count;
			} 
			 
			if(accumulateLabel.length()>0){
				accumulateLabel += ", ";
			}
			accumulateLabel += orderAtAndBefore;
			
			if(accumulatePercentLabel.length()>0){
				accumulatePercentLabel += ", ";
			} 
					
			accumulatePercentLabel += df.format(100*(double)orderAtAndBefore/(double)totalTests);
			
			if(atPosLabel.length()>0){
				atPosLabel += ", ";
			}
			atPosLabel += orderAt;
		}
		
		BufferedWriter bf =  new BufferedWriter(new FileWriter(new File(file), false)); 
		bf.write("y1=["+accumulateLabel +"]\r\n");  
		bf.write("y2=["+atPosLabel +"]\r\n");  
		bf.write("percents=["+accumulatePercentLabel +"]\r\n");  
		bf.close(); 
	} 
	
	
	static void saveNDCGs(List<PredictResult> results) throws IOException{
		File csv = new File("experiment.csv"); 
 
		int betterCases = 0;
		BufferedWriter bf =  new BufferedWriter(new FileWriter(csv, false));		
		for(PredictResult rs: results){
			String line = rs.app + "," + rs.ndcg+ "," + rs.ndcg2 + "," + rs.bloatScriptOrderInUsedMem +"," + rs.bloatScriptOrderInPredict + ",,," + (rs.ndcg-rs.ndcg2);  
			bf.write(line + "\r\n");   
			
			if((rs.ndcg-rs.ndcg2)>0){
				betterCases++;
			}
		}		
		bf.close();
 
		bf =  new BufferedWriter(new FileWriter(new File("ndcg.txt"), false)); 
		for(PredictResult rs: results){ 
			bf.write(rs.ndcg + ",\r\n");  
		}
		bf.close();
		
		bf =  new BufferedWriter(new FileWriter(new File("ndcg2.txt"), false)); 
		for(PredictResult rs: results){ 
			bf.write(rs.ndcg2 + ",\r\n");  
		}
		bf.close();
		
		System.out.println("Tests with better NDCG: " + betterCases);
	} 
	
 
	
	//count参数表示随机选择几组作为训练
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void findTrainGroups(int index, int count, String[] webapps, ArrayList<String> trainedApps, List<List<String>> trainedGroups) throws Exception{ 
		if (count == 1) {
			for (int i = index; i < webapps.length; i++) {
				List<String> forkTrainedApps = (ArrayList)trainedApps.clone();
				forkTrainedApps.add(webapps[i]); 
				
				trainedGroups.add(forkTrainedApps);
			}
		} else if (count > 1) {
			for (int i = index; i <= webapps.length - count; i++) {
				ArrayList<String> forkTrainedApps = (ArrayList)trainedApps.clone();
				forkTrainedApps.add(webapps[i]);
				
				findTrainGroups(i + 1, count - 1, webapps, forkTrainedApps, trainedGroups); 
			} 
		} 
	}
}

	