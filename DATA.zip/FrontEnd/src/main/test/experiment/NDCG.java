package test.experiment;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class NDCG {
	@Test
	public void testNDCG1() { 
		int rel_DCG[] = {}; 
		int rel_IDCG[] = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
		double NDCG = NDCG1(rel_DCG, rel_IDCG);
	 
		DecimalFormat df = new DecimalFormat("0.00%"); 
		System.out.println("NDCG1    "+ df.format(NDCG));
	}
	
	@Test
	public void testNDCG2() {
		int rel_DCG[] =  {3,10,7,8,5,4,2,6,9,1}; 
		int rel_IDCG[] = {  10,9,8, 7, 6, 5, 4, 3, 2,  1 };
		double NDCG = NDCG2(rel_DCG, rel_IDCG);
	 
		DecimalFormat df = new DecimalFormat("0.00%"); 
		System.out.println("NDCG2    " + df.format(NDCG));
	}
	
	@Test
	public void testListNDCG() {
		int rel_DCG[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 }; 
		List<Integer> ranked = new ArrayList<>();
		for(int r: rel_DCG){
			ranked.add(r);
		} 
		
		int rel_IDCG[] = { 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
		List<Integer> ideal = new ArrayList<>();
		for(int r: rel_IDCG){
			ideal.add(r);
		} 
		
		double NDCG = calcNDCG(ranked, ideal, ALGORITHM.NDCG2); 
		DecimalFormat df = new DecimalFormat("0.00%"); 
		System.out.println(df.format(NDCG));
	}
	
	
	
	public static enum ALGORITHM{ NDCG1, NDCG2};
	
	/**
	 * 计算排序结果的NDCG
	 * @param rankedList 
	 * @param idealList
	 * @return
	 */
	public static <T> double calcNDCG(List<T> rankedList, List<T> idealList, ALGORITHM algo){
		Map<T, Integer> relMap = new HashMap<>();
		int size = idealList.size();
		int rel_DCG[] = new int[size];
		int rel_IDCG[] = new int[size];
		
		// 理想序列中rel值逐渐减小
		int index = 0;
		for(T t: rankedList){
			int rel = size - index;
			relMap.put(t, rel);
			rel_IDCG[index] = rel;
			
			index++; 
		}
		
		index = 0;
		for(T t: idealList){
			int rel = relMap.get(t); 
			rel_DCG[index] = rel; 
			index++; 
		}
		
		switch(algo){
		case NDCG1: return NDCG1(rel_DCG, rel_IDCG);
		case NDCG2: 
		default:    return NDCG2(rel_DCG, rel_IDCG);
		}
	}
	
	public static <T> double calcNDCG2(List<T> rankedByUM, List<T> idealList, ALGORITHM algo){
		Map<T, Integer> relMap = new HashMap<>();
		int size = idealList.size();
		int rel_DCG[] = new int[size];
		int rel_IDCG[] = new int[size];
		
		// 理想序列中rel值逐渐减小
		int index = 0;
		for(T t: rankedByUM){
			int rel = size - index;
			relMap.put(t, rel);
			rel_IDCG[index] = rel;
			
			index++; 
		}
		
		index = 0;
		for(T t: idealList){
			int rel = relMap.get(t); 
			rel_DCG[index] = rel; 
			index++; 
		}
		
		switch(algo){
		case NDCG1: return NDCG1(rel_DCG, rel_IDCG);
		case NDCG2: 
		default:    return NDCG2(rel_DCG, rel_IDCG);
		}
	}
	
	
	/***
	 * 采用 rel_i/log2(i+1) 公式 
	 */
	public static double NDCG1(int rel_DCG[], int rel_IDCG[]){    
		double DCG = DCG1(rel_DCG);   
		double IDCG = DCG1(rel_IDCG);   
		double NDCG = DCG / IDCG;
		return NDCG; 
	}	
	
	public static double DCG1(int[] rel_DCG){
		double DCG = 0;  
	 
		for (int i = 1; i <= rel_DCG.length; i++) {
			double denominator = (Math.log(i + 1)) / (Math.log(2));
			DCG += rel_DCG[i-1] / denominator;
		}
		
		return DCG;
	}
	
	
	/***
	 * 采用 (2^rel_i-1)/log2(i+1) 公式 
	 */
	public static double NDCG2(int rel_DCG[], int rel_IDCG[]){    
		double DCG = DCG2(rel_DCG);   
		double IDCG = DCG2(rel_IDCG);   
		double NDCG = DCG / IDCG;
		return NDCG; 
	}	
	
	public static double DCG2(int[] rel_DCG){
		double DCG = 0;  
	 
		for (int i = 1; i <= rel_DCG.length; i++) {
			double numerator = Math.pow(2, rel_DCG[i-1]) - 1;
			double denominator = (Math.log(i + 1)) / (Math.log(2));
			DCG += numerator / denominator;
		}
		
		return DCG;
	}
	
}


