package test.experiment;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.junit.Test;

import test.experiment.NDCG.ALGORITHM;

import com.memtest.test.MemoryState;
import com.memtest.test.TestRecord;
import com.memtest.util.CmdRunner;
import com.memtest.util.Utils;

/**
 * 这里主要是训练和预测 有一些方法没用到 后续可以删掉
 * @author kyriezxh
 *
 */
public class TrainAndPredict {
	@Test
	public void testPrediction() throws Exception{
		String app = "solo";
		String RECORD_FOLDER = "experiment/records";
		String TRAIN_FOLDER = "output/train";
		String modelFile = "output/train/test.model";
		
		ArrayList<PredictResult> results = new ArrayList<>();
		doPrediction(app, RECORD_FOLDER, 500, TRAIN_FOLDER, new File(modelFile), results);
		
		PredictResult rs = results.get(0);  
		double ndcg = rs.ndcg;
		DecimalFormat df = new DecimalFormat("0.00%"); 
		System.out.println("NDCG: " + df.format(ndcg));
	} 
	
	
	static void trainModel(String recordFolder, String trainFolder, int largeRounds, Collection<String> trainApps) throws Exception{ 
		Map<String, String> scriptLabels = new HashMap<>();
		Map<String, List<TestRecord>> appRecords = new HashMap<>();
		for(String app: trainApps){ 
			ArrayList<TestRecord> largeRoundRecords = loadAppTestRecords(recordFolder, Collections.singletonList(app), largeRounds); 
			calcLabels(largeRoundRecords, scriptLabels);
			
			ArrayList<TestRecord> records = loadAppTestRecords(recordFolder, Collections.singletonList(app), 1);
			for(TestRecord r: records){
				String scriptName = r.getScriptName();
				String label = scriptLabels.get(scriptName);
				if(label==null || label.length()==0){
					throw new Exception("Large rounds recors not found!");
				}
				
				r.setManualScore(label);
			}
			
			appRecords.put(app, records);
		}		

		File trainFile = new File(trainFolder,"test" + ".train");		
		File modelFile = new File(trainFolder, "test" + ".model");
		createTrainOrTestFile(trainFile, appRecords);
		
		trainPredictModel(trainFile, modelFile);
	}
	
	
	/**
	 * 预测膨胀风险值 ，并评估预测效果
	 */
	static void doPrediction(String app, String recordFolder, int largeRounds, String trainFolder, File modelFile, List<PredictResult> results) throws Exception{  	
		DateFormat fmt =new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		String time = fmt.format(new Date()); 
		File testFile = new File(trainFolder, time + ".test");	
		File predictFile = new File(trainFolder, time + ".predict");	
		
		Date predictStart = new Date();
		Map<String, List<TestRecord>> appRecords = new HashMap<>();
		ArrayList<TestRecord> records = loadAppTestRecords(recordFolder, Collections.singletonList(app), 1);
		appRecords.put(app, records);
		
		createTrainOrTestFile(testFile, appRecords); 
		
		predict(records, modelFile, testFile, predictFile);
		
		Date predictEnd = new Date();
		
		Map<String,Double> nameToBloat = new HashMap<String, Double>();
		Map<String,Long> nameToUsedMemory = new HashMap<String, Long>();
		for(TestRecord r : records){
			//System.out.println(r.getScriptName()+r.getBloatWeight());
			nameToBloat.put(r.getScriptName(), r.getBloatWeight());
			nameToUsedMemory.put(r.getScriptName(), r.getLastMemoryState().getUsedMemory());
		}			
	    
		ArrayList<TestRecord> ranked = sortByPredictedScore(records);
		String rankedList = "";
		for(TestRecord r : ranked){
			if(rankedList.length()>0){
				rankedList += ", ";
			}
			
			rankedList += r.getScriptName();
		}

		System.out.println("ranked result" + rankedList);
		
		List<Double> scoreList = new ArrayList<Double>();
		String scores = "";
		for (TestRecord testRecord : ranked) {
			double score = testRecord.getBloatWeight();
			if(scores.length()>0) scores += ",";
			scores += score;
			scoreList.add(score);
		}
		System.out.println("scores: " + scores);
		
		ArrayList<TestRecord> rankedbyUM = sortByUsedMemory(records);
		List<Long> usedmemoryList = new ArrayList<Long>();
		for(TestRecord testRecord : rankedbyUM){
			Long usedmemory = testRecord.getLastMemoryState().getUsedMemory();
			usedmemoryList.add(usedmemory);
		}
		
		//将500轮记录进行排序,排名第一的认为是膨胀脚本 
		ArrayList<TestRecord> records500 = loadAppTestRecords(recordFolder, Collections.singletonList(app), largeRounds);
		ArrayList<TestRecord> rankedbyLargeruns = sortByUsedMemory(records500);
		Map<String, Long> scriptToLongRunMemory = getScriptLongTermMemoryUse(records500);		
		
		//输出该排序脚本
		String largeRuns = "";
		for(TestRecord r : rankedbyLargeruns){
			if(largeRuns.length()>0) largeRuns += ", ";
			largeRuns += r.getScriptName();			
		} 
		System.out.println("large runs： " + largeRuns);

		TestRecord bloatRecord = rankedbyLargeruns.get(0); 
    	String fullScriptName = bloatRecord.getScriptName(); 
    	
    	//list从0开始计数,为了方便后面统计,索引值+1
    	int orderInPredict = scoreList.indexOf(nameToBloat.get(fullScriptName)) + 1;
    	int orderInUsedMem = usedmemoryList.indexOf(nameToUsedMemory.get(fullScriptName))+1; 
    			
    	System.out.println("应用名称 " + app);
    	System.out.println("膨胀脚本名称为:" + fullScriptName);
    	System.out.println("膨胀脚本打分为:" + nameToBloat.get(fullScriptName));
    	
    	System.out.println("膨胀脚本打分排序为:" + orderInPredict);
    	System.out.println("膨胀脚本一轮内存消耗为:"+nameToUsedMemory.get(fullScriptName));
    	System.out.println("膨胀脚本一轮内存排序为:" + orderInUsedMem);
    	
    	ArrayList<TestRecord> ideal = sortByScriptData(records, scriptToLongRunMemory);	    	
		double ndcg = NDCG.calcNDCG(ranked, ideal, ALGORITHM.NDCG2);
		double ndcg2 = NDCG.calcNDCG2(rankedbyUM, ideal, ALGORITHM.NDCG2);
		
		System.out.println("实验1:" + ndcg);
		System.out.println("实验2:" + ndcg2);
		
		PredictResult result = new PredictResult();
		result.app = app;
		result.predictTime = predictEnd.getTime() - predictStart.getTime();
		result.bloatScript = fullScriptName;
		result.ndcg = ndcg;
		result.ndcg2 = ndcg2;
		result.rankedByPredict = ranked;
		result.rankedByUsedMem = rankedbyUM;
		result.bloatScriptOrderInPredict = orderInPredict;
		result.bloatScriptOrderInUsedMem = orderInUsedMem;
		result.longRunTime = getScriptLongTermExecTime(records500);
		results.add(result);
	}
	
	static class PredictResult{
		String app;
		
		long predictTime;
		double ndcg;
		double ndcg2;

		String bloatScript;
		ArrayList<TestRecord> rankedByPredict;
		ArrayList<TestRecord> rankedByUsedMem;
		Map<String, Long> longRunTime;
		
		int bloatScriptOrderInPredict;
    	int bloatScriptOrderInUsedMem;
	}
	
	static ArrayList<TestRecord> loadAppTestRecords(String recordFolder, Collection<String> apps, int runTimes) throws Exception{		
		ArrayList<TestRecord> records = new ArrayList<TestRecord>();
				
		for(String app: apps){
			File appDir = new File(recordFolder, app);
			File dir = new File(appDir, "" + runTimes);
			if(!dir.exists() || !dir.isDirectory()){
				throw new Exception("App record not exist: " + app + ", " + runTimes);
			}
			
			File[] files = dir.listFiles();
			if(files!=null){
				for(File f: files){
					if(f.isDirectory()){
						throw new RuntimeException("目录结构异常");
					}
					
					TestRecord r = loadTestRecord(f);
					records.add(r);
				}
			}
		} 
 
		return records;
	}
	
		
	/** 读取脚本执行的记录文件  */
	static ArrayList<TestRecord> loadTestRecords(String[] folders) throws IOException{
		ArrayList<TestRecord> records = new ArrayList<TestRecord>();
		for(String folder: folders){
			File dir = new File(folder);
			if(!dir.isDirectory()){
				continue;
			}
			
			File[] files = dir.listFiles();
			if(files!=null){
				for(File f: files){
					if(f.isDirectory()){
						throw new RuntimeException("目录结构异常");
					}
					
					TestRecord r = loadTestRecord(f);
					records.add(r);
				}
			}
		}
		
		return records;
	}
	
	static TestRecord loadTestRecord(File file) throws IOException{
		String content = Utils.readFile(file.getCanonicalPath());
		JSONObject json = JSONObject.fromObject(content);
		TestRecord record = TestRecord.fromFileJSON(json);
		return record;
	}
	
	// Labels are used to sort the order between records
	static void calcLabels(ArrayList<TestRecord> records, Map<String, String> scriptScores){
		long LEVEL_GAP = 1000000;
		for(TestRecord r: records){
			long usedMemory = r.getLastMemoryState().getUsedMemory();
			if(usedMemory<0){
				usedMemory = 0;
			}
			
			long label = usedMemory/LEVEL_GAP;
			scriptScores.put(r.getScriptName(), "" + label);
		}
	}
	
	@SuppressWarnings("unchecked")
	static void sortPredictScore(ArrayList<TestRecord> records){
		ArrayList<Double> arr = new ArrayList<Double>();
		ArrayList<TestRecord> clone = (ArrayList<TestRecord>) records.clone();
		for (TestRecord testRecord : clone) {
			double bloat= testRecord.getBloatWeight();
			arr.add(bloat);
		}
		Collections.sort(arr);
		System.out.println(arr);
	}

	static ArrayList<TestRecord> sortByPredictedScore(ArrayList<TestRecord> records){
		@SuppressWarnings("unchecked")
		ArrayList<TestRecord> clone = (ArrayList<TestRecord>)records.clone(); 
		clone.sort(new Comparator<TestRecord>() { 
			@Override
			public int compare(TestRecord o1, TestRecord o2) {
				double v1 = o1.getBloatWeight();
				double v2 = o2.getBloatWeight();
				if(v1!=v2)
					return v1-v2>0? -1:1;
				else
					return 0;
			}
		});  
		
		return clone;
	}
	
	static ArrayList<TestRecord> sortByUsedMemory(ArrayList<TestRecord> records) throws IOException{
		@SuppressWarnings("unchecked")
		ArrayList<TestRecord> clone = (ArrayList<TestRecord>)records.clone();  
		clone.sort(new Comparator<TestRecord>() { 
			@Override
			public int compare(TestRecord o1, TestRecord o2) {
				long v1 = o1.getLastMemoryState().getUsedMemory();
				long v2 = o2.getLastMemoryState().getUsedMemory();
				if(v1!=v2)
					return v1-v2>0? -1:1;
				else
					return 0;
			}
		});  
		
		return clone;
	}

	static Map<String, Long> getScriptLongTermMemoryUse(ArrayList<TestRecord> records){
		Map<String, Long> map = new HashMap<>();
		for(TestRecord r: records){
			long mem = r.getLastMemoryState().getUsedMemory();
			map.put(r.getScriptName(), mem);
		}
		
		return map;
	}
	
	static Map<String, Long> getScriptLongTermExecTime(ArrayList<TestRecord> records){
		Map<String, Long> map = new HashMap<>();
		for(TestRecord r: records){
			long time = r.getElapsedTime();
			map.put(r.getScriptName(), time);
		}
		
		return map;
	}
	
	static ArrayList<TestRecord> sortByScriptData(ArrayList<TestRecord> records, Map<String, Long> scriptData) throws IOException{
		@SuppressWarnings("unchecked")
		ArrayList<TestRecord> clone = (ArrayList<TestRecord>)records.clone();  
		clone.sort(new Comparator<TestRecord>() { 
			@Override
			public int compare(TestRecord o1, TestRecord o2) { 
				Long v1 = scriptData.get(o1.getScriptName());
				Long v2 = scriptData.get(o2.getScriptName());
				if(v1==null){
					throw new RuntimeException("No data found: " + o1.getScriptName());
				}
				if(v2==null){
					throw new RuntimeException("No data found: " + o2.getScriptName());
				}				
				
				if(v1!=v2)
					return v1-v2>0? -1:1;
				else
					return 0;
			}
		});  
		
		return clone;
	}	

	static void createTrainOrTestFile(File file, Map<String, List<TestRecord>> appRecords) throws IOException  {
		File dir = file.getParentFile();
		if(!dir.exists()){
			dir.mkdirs();
		}
		
		if (file.exists()) {
			file.delete();
		}
		file.createNewFile();
		
		FileWriter writer = new FileWriter(file);
		int qid = 1;
		for(Map.Entry<String, List<TestRecord>> e: appRecords.entrySet()){
			String app = e.getKey();
			List<TestRecord> records = e.getValue();
			
			String content = nomalized(app, qid, records);
			writer.write(content); 
			
			qid++;
		} 
		
		writer.close();
	}  
	

	public static String nomalized(String app, int qid, List<TestRecord> records ){ 
		ArrayList<Long> arrUsedMem = new ArrayList<Long>();
		ArrayList<Long> arrObjectAlloc = new ArrayList<Long>();
		ArrayList<Long> arrFreedObjects = new ArrayList<Long>();
		ArrayList<Long> arrAllocArray = new ArrayList<Long>();
		ArrayList<Long> arrFieldMod = new ArrayList<Long>();
		//ArrayList<Long> arrOpenMethods = new ArrayList<Long>();
		ArrayList<Long> arrCloseMethods = new ArrayList<Long>();
		ArrayList<Long> arrElapsedTime = new ArrayList<Long>();
		
		int MemUnit = 1000000;
		
		for (TestRecord r : records) {
			MemoryState state = r.getLastMemoryState();
			
			arrUsedMem.add(state.getUsedMemory()/MemUnit);
			
			long objectCount = state.getAllocatedObjectCount();// + state.getImageMethodCount()* 100 ;
			arrObjectAlloc.add(objectCount);
 
			arrAllocArray.add((long)state.getAllocatedArrayCount());  
			arrFreedObjects.add((long)state.getFreedObjectCount()); 
			arrFieldMod.add((long)state.getFieldModifiedCount());  
			//arrOpenMethods.add((long)Math.log(state.getOpenMethodCount())); 
			arrCloseMethods.add((long)Math.log(state.getCloseMethodCount()+state.getOpenMethodCount()));  //
			arrElapsedTime.add(r.getElapsedTime()/1000);
		}
 
		Distribution dUseMem = calcDistribution(arrUsedMem);
		Distribution dObjAlloc = calcDistribution(arrObjectAlloc);		
		Distribution dArrayAlloc = calcDistribution(arrAllocArray);
		Distribution dObjFree = calcDistribution(arrFreedObjects);
		Distribution dFieldMod = calcDistribution(arrFieldMod);
		//Distribution dOpens = calcDistribution(arrOpenMethods);
		Distribution dCloses = calcDistribution(arrCloseMethods);
		Distribution dTime = calcDistribution(arrElapsedTime);
		
        StringBuffer buffer = new StringBuffer();  
		buffer.append("# query " + qid + ":" + app + "\r\n"); 
		
		for (TestRecord record : records) {
			MemoryState state = record.getLastMemoryState(); 
			
			//实际预测时，target并没有实际意义，但是必须设置值，否则报错
			//https://www.cs.cornell.edu/people/tj/svm_light/svm_rank.html
			String target = "".equals(record.getManualScore()) ? "1": record.getManualScore(); 
			DecimalFormat df = new DecimalFormat("#0.0000");   
			
			long allocObjects = state.getAllocatedObjectCount();// + state.getImageMethodCount() * 100; 
			String fAllocObj = getFeatureValue(df, allocObjects, dObjAlloc);
			
			long freeObjects = state.getFreedObjectCount();
			String fFree = getFeatureValue(df, freeObjects, dObjFree);
			
			long allocArray = state.getAllocatedArrayCount();
			String fAllocArray = getFeatureValue(df, allocArray, dArrayAlloc);
			
			long fieldMod = state.getFieldModifiedCount();
			String fFieldMod = getFeatureValue(df, fieldMod, dFieldMod);
			
			//long opens = state.getOpenMethodCount();
			//String fOpens = getFeatureValue(df, (long)Math.log(opens), dOpens);
 
			String fCloses = getFeatureValue(df, (long)Math.log(state.getOpenMethodCount()+state.getCloseMethodCount()), dCloses);  
			
			long time = record.getElapsedTime();
			String fTime = getFeatureValue(df, time/1000, dTime); 
			
			long useMem = state.getUsedMemory();
			String fUseMem = getFeatureValue(df, useMem/MemUnit, dUseMem); 
			
			int index = 1;
			String rec = target	+ " qid:" + qid 
					+ " " + (index++) + ":" + fAllocObj
					+ " " + (index++) + ":"	+ fFree
					+ " " + (index++) + ":" + fAllocArray
					+ " " + (index++) + ":" + fFieldMod
					//+ " " + (index++) + ":" + fOpens
					+ " " + (index++) + ":" + fCloses
					//+ " " + (index++) + ":" + fTime
					+ " " + (index++) + ":" + fUseMem
 					+ "\r\n"; 
			buffer.append(rec);
		}

		return buffer.toString();
	}
	
	
	static class Distribution{
		long max;
		long min;
	}
	
	static Distribution calcDistribution(ArrayList<Long> data){
		Distribution d = new Distribution();
		d.max = Collections.max(data); 
		d.min = Collections.min(data);
		return d;
	}
	
	static String getFeatureValue(DecimalFormat df, long value, Distribution d){
		String fs = null;		
		if(true){
			double f;
			if(d.max!=0 ){
				f = (double)value/(double)d.max;
			}
			else{
				f = 0;
			}
			
			fs = df.format(f);
		}
		else{
			fs = "" + value;
		} 
		
		return fs;
	}
	
	
	static String createTrainOrTestFile(List<TestRecord> records) {
		StringBuffer buffer = new StringBuffer();

		String filein = "# query 1 " + "\r\n";
		buffer.append(filein);

		for (TestRecord record : records) {
			List<MemoryState> states = record.getMemoryStates();
			if (states.isEmpty()) {
				continue;
			}

			MemoryState state = states.get(states.size() - 1);

			// 实际预测时，target并没有实际意义，但是必须设置值，否则报错
			// https://www.cs.cornell.edu/people/tj/svm_light/svm_rank.html
			String target = "".equals(record.getManualScore()) ? "1" : record.getManualScore();

			long objectCount = state.getAllocatedObjectCount() + state.getImageMethodCount() * 100;
			String rec = target
					+ " qid:1"
					// +" 1:"+record.getLastMemoryState().getUsedMemory()
					+ " 1:" + objectCount 
					+ " 2:" + state.getFreedObjectCount()
					+ " 3:" + state.getAllocatedArrayCount() 
					+ " 4:"	+ state.getFieldModifiedCount() 
					+ " 5:"	+ state.getOpenMethodCount() 
					+ " 6:"	+ state.getCloseMethodCount() 
					+ " 7:"	+ record.getElapsedTime() + "\r\n";
			buffer.append(rec);
		}

		return buffer.toString();
	}

	static void trainPredictModel(File trainFile, File modelFile) throws Exception {
		File fsvmHome = new File(".\\lib\\svm");
		String svmHome = fsvmHome.getCanonicalPath(); 
		String libSVM = "\"" + fsvmHome.getCanonicalPath() + "\\svm_rank_learn.exe\""; 
		String[] cmds = {
			libSVM,
			"-c",
			"1",
			"-t",
			"2",
		    trainFile.getCanonicalPath(),
			modelFile.getCanonicalPath()
		};
		//String cmd = libSVM + " -c 1 " + trainFile.getCanonicalPath() + " " + modelFile.getCanonicalPath(); 
		CmdRunner.runCommand(svmHome, Arrays.asList(cmds)); 
	}
	
	static void predict(List<TestRecord> records, File modelFile, File testFile, File predictFile) throws Exception { 
		File fsvmHome = new File("lib\\svm");
		String svmHome = fsvmHome.getCanonicalPath();
		String libSVM = "\"" + fsvmHome.getCanonicalPath() + "\\svm_rank_classify.exe\""; 
		String[] cmds = {
				libSVM,
				testFile.getCanonicalPath() ,
				modelFile.getCanonicalPath(),
				predictFile.getCanonicalPath()
		};
		//String cmd = libSVM + " " + testFile.getCanonicalPath() 
		//		+ " " + modelFile.getCanonicalPath() 
		//		+ " " + predictFile.getCanonicalPath();
		CmdRunner.runCommand(svmHome, Arrays.asList(cmds));
		
		List<Double> scores = readScores(predictFile); 
		for(int i = 0;i<scores.size();i++){
			TestRecord record = records.get(i);
			record.setBloatWeight(scores.get(i)); 
		} 
	}	
	
	static List<Double> readScores(File file) throws IOException{
		List<Double> scores = new ArrayList<>();
		String encoding="UTF-8"; 
        if(file.isFile() && file.exists()){ 
        	InputStreamReader read = new InputStreamReader(new FileInputStream(file),encoding);
            BufferedReader bufferedReader = new BufferedReader(read);
            String lineTxt = null;
            while((lineTxt = bufferedReader.readLine()) != null){
           		scores.add(Double.parseDouble(lineTxt));
        	}
            read.close();
        }
        else{
       	 	throw new RuntimeException("找不到指定的文件");
        }
		return scores;
	}
}
