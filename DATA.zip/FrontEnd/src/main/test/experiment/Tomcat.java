package test.experiment;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException; 

import com.memtest.Global;
import com.memtest.core.ContainerType;
import com.memtest.core.TomcatContainer;

/**
 * 管理tomcat
 * @author zhouxu
 *
 */
public class Tomcat {
    public static void startTomcat() throws IOException {
		try {
			Global.v().init();
		} catch (Exception e) {
			e.printStackTrace();
		}

		String hostURL = "http://localhost:8080";
		String location = new File("../Monitor/tomcat").getCanonicalPath();
		TomcatContainer tomcat = new TomcatContainer(ContainerType.Default,	hostURL, new File(location));

		tomcat.startContainer();
	}
    
	public static void shutdownTomcat() throws IOException, UnsupportedEncodingException {
		String processName = null;
		Process p=Runtime.getRuntime().exec("cmd /c tasklist -fi \"imagename eq java.exe\"");
		BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream(),"utf-8"));
		String line=null;
		while((line=reader.readLine())!=null){
		    if(line.indexOf("java.exe")!=-1){
		    	 String[] lineArray = line.split(" ");
	                processName = lineArray[0].trim();
	                Runtime.getRuntime().exec("taskkill /IM " + processName);
		    }
		}
		
		reader.close();
	}
}
