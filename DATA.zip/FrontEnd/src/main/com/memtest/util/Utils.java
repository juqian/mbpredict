package com.memtest.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.UUID;



public class Utils {
	/**
	 * Each ID consists of a prefix and a UUID. e.g, testcase_uuid
	 */
	public static String createID(String prefix){
		 UUID uuid = UUID.randomUUID();
		 String id = prefix + "_" + uuid.toString();
		 return id;
	}
	

	
	public static File createTempDirectory(String parentDirectory, String prefix){	 
		for(int id = 0;; id++){
			String name = id==0? prefix: (prefix+"_" + id);			
			String path = parentDirectory + File.separator + name;
			File target = new File(path);
			if(!target.exists()){
				target.mkdirs();
				return target;
			} 
		} 
	}

	public static File createFile(String dir, String expectedName) { 
		String name, ext;
		int sp = expectedName.lastIndexOf('.');
		if(sp<0){
			name = expectedName;
			ext = "";
		}
		else{
			name = expectedName.substring(0, sp);
			ext = expectedName.substring(sp);
		}
		
		for(int id = 0;; id++){
			String targetName = id==0? name: (name+"_" + id);			
			String targetFilePath = dir + File.separator + targetName + ext;
			File target = new File(targetFilePath);
			if(!target.exists()){
				return target;
			} 
		} 
	}
	
	public static boolean  deleteFile(String dir,String endWith){		
		File file = new File(dir);
		File[] files = file.listFiles();
		
		boolean delete = false; 
		if(files!=null){ 
			for(File f:files){
				if(f.getName().endsWith(endWith)){
					f.delete();
					delete = true;
				}
			}
		}

		return delete; 
	}
	
	
	public static void saveTextToFile(String text, String filepath) throws IOException{ 
		PrintStream out = new PrintStream(new FileOutputStream(filepath));
		out.println(text);		
		out.close();		
	}
	
	public static void copyFolder(String srcFolder, String dstFolder) throws IOException{
		File dstf = new File(dstFolder);
		if(!dstf.exists()){
			dstf.mkdirs();
		}
		
		File srcf = new File(srcFolder);
		for(File f: srcf.listFiles()){
			String dstpath = dstFolder + File.separator + f.getName();
				
			if(f.isDirectory()){
				copyFolder(f.getAbsolutePath(), dstpath);
			}
			else{
				copyFile(f.getAbsolutePath(), dstpath);
			}
		}
	}
	
	
	public static void copyFile(String src, String dst) throws IOException {
		InputStream is = new FileInputStream(new File(src));
		copyFile(is, dst);
	}
	
	public static void copyFile(InputStream is, String dst) throws IOException {
		BufferedInputStream in = new BufferedInputStream(is);
		BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(dst));
 
		copy(in, out);
		
		in.close();
		out.close();
	}
	
	public static void copyFile(InputStream is, File dst) throws IOException {
		BufferedInputStream in = new BufferedInputStream(is);
		BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(dst));
 
		copy(in, out);
		
		in.close();
		out.close();
	}
	
	public static String readFile(String fileName){
		 InputStreamReader inputReader = null;
	     BufferedReader bufferReader = null;
	     OutputStream outputStream = null;
	     StringBuffer strBuffer  = null;
       try
       {
           InputStream inputStream = new FileInputStream(fileName);
           inputReader = new InputStreamReader(inputStream);
           bufferReader = new BufferedReader(inputReader);
            
           String line = null;
           strBuffer = new StringBuffer();
                
           while ((line = bufferReader.readLine()) != null) {
               strBuffer.append(line+ "\n");
           } 
            
       } catch (IOException e) {
          e.printStackTrace();
       }finally {
       	try {
       		if(inputReader!=null) inputReader.close();
       		if(bufferReader!=null)  bufferReader.close();
       		if(outputStream!=null)  outputStream.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
       	
       }
		
		return strBuffer.toString();
	}
	
	public static void writeFile(File file,String text){ 
		FileWriter  writer  = null;
		try{
			writer = new FileWriter(file);
			writer.write(text);  
			writer.flush();
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally { }
	}
	
	static final int BUFFER_SIZE = 1<<10;
	
	public static void copy(InputStream in, OutputStream out) throws IOException {
		byte buf[] = new byte[BUFFER_SIZE];
		while (true) {
			int size = in.read(buf);
			if (size <= 0)
				break;

			out.write(buf, 0, size);
		}
	}
	
	public static byte[] getBytes(InputStream in) throws IOException {
		BufferedInputStream bis = new BufferedInputStream(in);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		byte buf[] = new byte[BUFFER_SIZE];
		while (true) {
			int size = bis.read(buf);
			if (size <= 0)
				break;

			out.write(buf, 0, size);
		}
		
		return out.toByteArray();
	}
	
	//b[0]存高位，大端
	public static byte[] intToBytes(int i) {  
        byte[] b = new byte[4];  
        b[0] = (byte) (i >>> 24);  
        b[1] = (byte) (i >>> 16);  
        b[2] = (byte) (i >>> 8);  
        b[3] = (byte) i;  
        return b;  
    } 
	
	public static void clearDir(File dir){	
		if(dir.isDirectory()){
			File[] files = dir.listFiles();
			if(files==null || files.length==0){ 
				return;
			}
			
			for(File f: files){			
				deleteFileOrDir(f);
			}
		} 
	}
	
	public static void deleteFileOrDir(File file){	
		if(file.isDirectory()){
			if(file.listFiles().length==0){
				file.delete();
				return;
			}
			for(File f: file.listFiles()){			
				deleteFileOrDir(f);
			}
		}	
		
		boolean bSucc = file.delete();
		if(!bSucc)
			file.deleteOnExit();
	}
	
	public static void deleteFileOrDir(File file, boolean deleteOnExit){	
		if(file.isDirectory()){
			for(File f: file.listFiles()){			
				deleteFileOrDir(f, deleteOnExit);
			}
		}	
		
		if(deleteOnExit){
			file.deleteOnExit();
		}
		else{
			boolean bSucc = file.delete();
			if(!bSucc)
				file.deleteOnExit();
		}		
	}
	
	public static Object call(String className, String methodName, Class<?>[] paramTypes, Object receiver, Object... args) throws Exception{
		Class<?> c = Class.forName(className);			
		Method m = c.getMethod(methodName, paramTypes);
		Object ret = m.invoke(receiver, args);		 
		return ret;
	}
	
	public static Object call(Class<?> clazz, String methodName, Class<?>[] paramTypes, Object receiver, Object... args) throws Exception{
		Method m = clazz.getMethod(methodName, paramTypes);
		Object ret = m.invoke(receiver, args);		 
		return ret;
	}
	
	public static Object call(Object object, String methodName, Class<?>[] paramTypes, Object receiver, Object... args) throws Exception{
		Class<?> clazz = object.getClass();
		Method m = clazz.getMethod(methodName, paramTypes);
		Object ret = m.invoke(receiver, args);		 
		return ret;
	}

	public static <T> Set<T> getMultiMapValue(Map<String, Set<T>> map, String key){
		Set<T> set = map.get(key);
		if(set==null){
			set = new HashSet<T>();
			map.put(key, set);
		} 
		 
		return set;
	}
	
	public static boolean isEmptyString(String s){
		return (s==null || s.trim().length()==0);
	}
	
	public static boolean equals(String a, String b){
		return (a==b) || (a!=null && a.equals(b));
	}
	
	/**
	 * Dirty hack to set environment variable, may not work for all Java versions
	 * @param newenv
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void setEnv(Map<String, String> newenv){
		try{
	        Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
	        Field theEnvironmentField = processEnvironmentClass.getDeclaredField("theEnvironment");
	        theEnvironmentField.setAccessible(true);
	        Map<String, String> env = (Map<String, String>) theEnvironmentField.get(null);
	        env.putAll(newenv);
	        Field theCaseInsensitiveEnvironmentField = processEnvironmentClass.getDeclaredField("theCaseInsensitiveEnvironment");
	        theCaseInsensitiveEnvironmentField.setAccessible(true);
	        Map<String, String> cienv = (Map<String, String>) theCaseInsensitiveEnvironmentField.get(null);
	        cienv.putAll(newenv); 
			
			System.setProperty("java.library.path", newenv.get("PATH"));
			//set sys_paths to null
			final Field sysPathsField = ClassLoader.class.getDeclaredField("sys_paths");
			sysPathsField.setAccessible(true);
			sysPathsField.set(null, null);
	    }
	    catch (NoSuchFieldException e)
	    {
	      try {
	        Class[] classes = Collections.class.getDeclaredClasses();
	        Map<String, String> env = System.getenv();
	        for(Class cl : classes) {
	            if("java.util.Collections$UnmodifiableMap".equals(cl.getName())) {
	                Field field = cl.getDeclaredField("m");
	                field.setAccessible(true);
	                Object obj = field.get(env);
	                Map<String, String> map = (Map<String, String>) obj;
	                map.clear();
	                map.putAll(newenv);
	            }
	        }
	      } catch (Exception e2) {
	        e2.printStackTrace();
	      }
	    } catch (Exception e1) {
	        e1.printStackTrace();
	    }
	}
	
	public static boolean isInteger(String value) {
		try {
			Integer.parseInt(value);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public static boolean isDouble(String value) {
		try {
			Double.parseDouble(value);
			if (value.contains("."))
				return true;
			return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}
	
	public static boolean isNumber(String value) {
		return isInteger(value) || isDouble(value);
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T[][] generateAllCombinations(T[] array, int len) {
		int total = (int) Math.pow(array.length, len);

		T[][] out = (T[][]) Array.newInstance(array.getClass(), total);

		for (int i = 0; i < total; i++) {
			T[] combination = (T[]) Array.newInstance(array.getClass().getComponentType(), len);

			int base = total / array.length;
			long remain = i;
			for (int k = 0; k < len; k++) {
				int index = (int) (remain / base);
				remain = remain % base;
				base = base / array.length;
				combination[k] = array[index];
			}
			
			out[i] = combination;
		}

		return out;
	}
	
	public static <T> List<T> toArrayList(T[] t){
		List<T> list = new ArrayList<>();
		for(int i=0;i<t.length;i++){
			list.add(t[i]);
		}
		return list;
	}
	
	public static <T> boolean isEquals(T[] t1,T[] t2){
		 for(int i=0;i<t1.length;i++){
			 T t = t1[i];
			 if(!toArrayList(t2).contains(t)){
				 return false;
			 }
		 }
		 for(int i=0;i<t2.length;i++){
			 T t = t2[i];
			 if(!toArrayList(t1).contains(t)){
				 return false;
			 }
		 }
		return true;
	}
	
	public static Date string2Date(String str) throws ParseException{
		DateFormat fmt =new SimpleDateFormat("yyyy-MM-dd");
		Date date = fmt.parse(str);
		return date;
	}
	
	public static Date string2DateTime(String str) throws ParseException{
		DateFormat fmt =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = fmt.parse(str);
		return date;
	}
	
	public static Date string2Time(String str) throws ParseException{
		DateFormat fmt =new SimpleDateFormat("HH:mm:ss");
		Date date = fmt.parse(str);
		return date;
	}
	
	
	public static String date2String(Date date){
		DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		String time = fmt.format(date);
		return time;
	}
	
	public static String time2String(Date date) {
		DateFormat fmt =new SimpleDateFormat("HH:mm:ss");
		String time = fmt.format(date);
		return time;
	}
	
	public static String dateTime2String(Date date) {
		DateFormat fmt =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = fmt.format(date);
		return time;
	}
	
	public static String dateTime2ShortString(Date date) {
		DateFormat fmt =new SimpleDateFormat("yy-MM-dd HH:mm");
		String time = fmt.format(date);
		return time;
	}
	
	public static String dateTime2WSString(Date date) {
		DateFormat fmt =new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		String time = fmt.format(date);
		return time;
	}  
	
	public static Date wsString2DateTime(String str) throws ParseException{
		DateFormat fmt =new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Date date = fmt.parse(str);
		return date;
	}
	
	public static Object[] getIntersection(Object[] arr1, Object[] arr2) {
		Map<Object, Boolean> map = new HashMap<Object, Boolean>();
		LinkedList<Object> list = new LinkedList<Object>();
		for (Object str : arr1) {
			if (!map.containsKey(str)) {
				map.put(str, Boolean.FALSE);
			}
		}
		for (Object str : arr2) {
			if (map.containsKey(str)) {
				map.put(str, Boolean.TRUE);
			}
		}
		for (Entry<Object, Boolean> e : map.entrySet()) {
			if (e.getValue().equals(Boolean.TRUE)) {
				list.add(e.getKey());
			}
		}
		Object[] result = {};
		return list.toArray(result);
	}
	
	
	public static boolean equals(Object a, Object b){
		if(a==null){
			return (a==b);
		}
		else{
			return a.equals(b);
		}
	}
	
	public static <T> T getMapValue(Map<?,T> map, Object key){
		return map==null? null: map.get(key);
	}
	


	public static int random(int i, int j) {
		Random ran = new Random();
		return i+ran.nextInt(j);
	}
}
