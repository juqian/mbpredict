package com.memtest.util;
 
//import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
//import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

 

public class CmdRunner {
	/**
	 * Non-blocking thread output collector.
	 * Prevent the dead lock when calling Process.waitFor() while collecting outputs.
	 * 
	 * Bottom line: you will not be able to capture Input or Output Stream 
	 * of a program that deals directly with the console.
	 */
	static class ProcessOutputCollector {
		private static class ProcessClearStream extends Thread {
			InputStream is;
			private String s = "";
			PrintStream out;

			ProcessClearStream(InputStream inputStream, PrintStream out) {
				super("CollectProcessIO");
				
				this.is = inputStream;		
				this.out = out;
				
				this.setPriority(Thread.MAX_PRIORITY);
			}
			
			public String getOutput(){
				return s;
			}
			
			public boolean avaliable(){
				try {
					return is.available()>0;
				} catch (IOException e) {  
				}
				
				return false;
			}

			public void run() {
//				InputStreamReader inputStreamReader = new InputStreamReader(is);
//				BufferedReader br = new BufferedReader(inputStreamReader);
				
				try { 
//					String line = null;
					while (!Thread.interrupted()) {
//						while(is.available()==0){
//							Thread.sleep(50);
//						}
//						
//						line = br.readLine();
//						if(line==null){
//							break;
//						}
//						 
//						s += line + "\n";
//						if(out!=null){
//							out.println(line);
//						} 
												
						
						byte[] buffer = new byte[1024];
						int bytesRead = 0;
					    if ((bytesRead = is.read(buffer)) >= 0) {
					    	//out.write(buffer, 0, bytesRead);
					    	String s = new String(buffer, 0, bytesRead);
					    	out.println(s);
					    	out.flush();
					    }
					    else{
					    	break;
					    }
					}			 
				} catch (IOException ioe) {
					//ioe.printStackTrace();
				}
				//catch (InterruptedException e) {}
				
				out.flush();
			}
		}
		
		private ProcessClearStream tStdout;
		private ProcessClearStream tStderr;
		
		public ProcessOutputCollector(Process p, PrintStream out, PrintStream err){
			tStdout = new ProcessClearStream(p.getInputStream(), out);
			tStderr = new ProcessClearStream(p.getErrorStream(), err);
		}
		
		public void startCollector(){
			tStdout.start();
			tStderr.start();
		}
		
		public void endCollector() throws InterruptedException{ 
			tStdout.join();
			tStderr.join();
		}
		
		public void endCollector(boolean forceClose) throws InterruptedException{
			if(forceClose){
				try {
					while(tStdout.avaliable() || tStderr.avaliable()){
						Thread.sleep(50);
					}
					tStdout.interrupt();
					tStderr.interrupt();
					
					tStdout.is.close();
					if(tStdout.out!=System.out && tStdout.out!=System.err) {
						tStdout.out.close();
					}
					
					tStderr.is.close();
					if(tStderr.out!=System.out && tStderr.out!=System.err) {
						tStderr.out.close();
					} 
				} catch (IOException e) { 
					//e.printStackTrace();
				}
			}

			tStdout.join();
			tStderr.join();
		}
		
		public String getStdout(){
			return tStdout.getOutput();
		}
		
		public String getStderr(){
			return tStderr.getOutput();
		}
	}

	public static void printProcessIO(Process process, PrintStream out, PrintStream err, boolean waitForProcEnd) throws Exception{		 
		ProcessOutputCollector collector = new ProcessOutputCollector(process, out, err);
		collector.startCollector();
		
		if(waitForProcEnd){ 
			collector.endCollector();
			int ret = process.waitFor(); 
			
			System.out.println("\nProcess exit value: " + ret);		
		}	 
	}
	
	public static void printProcessIO(Process process, PrintStream out, PrintStream err, 
			boolean waitForProcEnd, boolean waitForIOStreamClosed) throws Exception{		 
		ProcessOutputCollector collector = new ProcessOutputCollector(process, out, err);
		collector.startCollector();
		
		if(waitForProcEnd){ 
			int ret = process.waitFor();
			process.destroyForcibly();
			System.out.println("\nProcess exit value: " + ret);	 
		}
		
		if(waitForIOStreamClosed){
			collector.endCollector();
		}
		else{
			new Thread("WaitProcessIOEnd"){
				public void run() {
					try {
						if(!waitForProcEnd) {
							process.waitFor();
						}
						
						Thread.sleep(5000); 
						collector.endCollector(true);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				};
			}.start();
		}
	}
	 
	public static Process runCommand(String cmd){
        try{        	
            Process process = Runtime.getRuntime().exec(cmd);    
            printProcessIO(process, System.out, System.err, true);
            return process;
        }catch(Exception e){
            e.printStackTrace(System.err);
        }
        
        return null;
    }
	
	public static Process runCommand(String dir, String cmd){
        try{      	
            Process process= Runtime.getRuntime().exec(cmd, null, new File(dir));
            printProcessIO(process, System.out, System.err, true);
            return process;
        }catch(Exception e){           
            e.printStackTrace(System.err);
        }
        
        return null;
    }
	
	public static Process runCommand(String dir, List<String> cmd){
        try{        	
        	ProcessBuilder builder = new ProcessBuilder();
        	builder.directory(new File(dir));
        	builder.command(cmd);        	
            Process process=builder.start(); 
            printProcessIO(process, System.out, System.err, true,false); 
            return process;
        }catch(Exception e){           
            e.printStackTrace(System.err);
        }
        
        return null;
    }
	
	public static Process runCommand(String dir, List<String> cmd, PrintStream out, PrintStream err, boolean waitForProcEnd){
        try{        	
        	ProcessBuilder builder = new ProcessBuilder();
        	builder.directory(new File(dir));
        	builder.command(cmd);     
            Process process=builder.start(); 
            printProcessIO(process, out, err, waitForProcEnd);
            return process;
        }catch(Exception e){           
            e.printStackTrace(System.err);
        }
        
        return null;
    }
	
	public static Process runCommand(String dir, Map<String,String> enviornmentVars, List<String> cmd, PrintStream out, PrintStream err, boolean waitForProcEnd){
        try{        	
        	ProcessBuilder builder = new ProcessBuilder();
        	builder.directory(new File(dir));
        	builder.command(cmd); 
        	Map<String, String> env = builder.environment();
        	env.putAll(enviornmentVars);
            Process process=builder.start(); 
            printProcessIO(process, out, err, waitForProcEnd);
            return process;
        }catch(Exception e){           
            e.printStackTrace(System.err);
        }
        
        return null;
    }
	
	public static Process runCommand(String dir, Map<String,String> enviornmentVars, List<String> cmd, 
			boolean showConsole, PrintStream out, PrintStream err, boolean waitForProcEnd){
        try{        	
        	if(showConsole){
        		cmd.add(0, "start");
        		cmd.add(0, "/c");
        		cmd.add(0, "cmd.exe");
        	}
        	
        	ProcessBuilder builder = new ProcessBuilder();
        	builder.directory(new File(dir));
        	builder.command(cmd); 
        	Map<String, String> env = builder.environment();
        	env.putAll(enviornmentVars);
            Process process=builder.start(); 
            printProcessIO(process, out, err, waitForProcEnd);
            return process;
        }catch(Exception e){           
            e.printStackTrace(System.err);
        }
        
        return null;
    }
	
	public static Process runCommand(String dir, Map<String,String> enviornmentVars, List<String> cmd, PrintStream out, PrintStream err, 
			boolean waitForProcEnd, boolean waitForIOStreamClose){
        try{        	
        	ProcessBuilder builder = new ProcessBuilder();
        	builder.directory(new File(dir));
        	builder.command(cmd); 
        	Map<String, String> env = builder.environment();
        	env.putAll(enviornmentVars);
            Process process=builder.start(); 
            if(out!=null && err!=null){
            	printProcessIO(process, out, err, waitForProcEnd, waitForIOStreamClose);
            }
            else{
            	if(waitForProcEnd){
            		int ret = process.waitFor();
        			process.destroyForcibly();
        			System.out.println("\nProcess Exit: " + ret);	
            	}
            }
            return process;
        }catch(Exception e){           
            e.printStackTrace(System.err);
        }
        
        return null;
    }
	
	public static void runCommand(String dir, Map<String,String> enviornmentVars, List<String> cmd, boolean waitForProcEnd){
		runCommand(dir, enviornmentVars, cmd, System.out, System.err, waitForProcEnd);
    }
	
	public static void runCommand(String dir, Map<String,String> enviornmentVars, List<String> cmd, 
			boolean waitForProcEnd, boolean waitForIOStreamClosed){
		runCommand(dir, enviornmentVars, cmd, System.out, System.err, waitForProcEnd, waitForIOStreamClosed);
    }
	
	public static String toCmdString(List<String> cmd){
		String s = "";
		for(String c: cmd){
			s += c + " ";
		}
	
		return s;
	}
	 
	public static void addArguments(String args, List<String> cmd){
		String[] splits = args.split("\t| ");
		for(String s: splits){
			cmd.add(s);
		}	
	} 
	
	
	public static List<String> getCmd(String s){
		java.util.List<String> cmd = new ArrayList<String>();
		String[] split = s.split(" ");
		for(int i=0;i<split.length;i++){
			cmd.add(split[i]);
		}
		return cmd;
	}
}
