package com.memtest;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import com.memtest.util.Utils;


/**
 * 
 * TODO All global objects stored here.  
 * 
 */
public class Global {
	private static Global _v = new Global(); 
	public static Global v() {
		return _v;
	}
	
	private Options options = null;


	private Global() {
		
	}
 
	public boolean init() throws Exception {
		InputStream is = loadConfigFile();		
		options = new Options(is); 	

		if(is!=null){
			is.close();
		}
		
		return true;
	}

	public InputStream loadConfigFile() throws Exception { 
		File configFile = new File("config.xml");
		InputStream is = null;
		try {
			is = new FileInputStream(configFile);
			System.out.println("Config: " + configFile.getCanonicalPath());
		} 
		catch (Exception e) {
			// 从jar包中复制 config文件
			byte[] bytes = Utils.getBytes(is);
			String text = new String(bytes);
			Utils.saveTextToFile(text, configFile.getCanonicalPath());
			is = new ByteArrayInputStream(bytes);
		}
		
		return is;
	}

 
	public Options getOptions() {
		return options;
	}

	public static String getAspectJLibHome(){
		String s = new File("lib/ajc").getAbsolutePath();
		return s;
	} 	
	
	public String getWeaverAgent(){
		try {
			File file = new File("lib/ajc/aspectjweaver.jar");
			return file.getCanonicalPath();
		} catch (IOException e) { 
			e.printStackTrace();
		}
		
		return null;
	}
}
