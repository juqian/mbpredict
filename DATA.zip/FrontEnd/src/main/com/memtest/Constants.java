package com.memtest;

public interface Constants { 
	public static final int MONITOR_SERVANT_PORT = 6006;
	public static final String MONITOR_REGISTRATION_CREDENTIAL = "aslkjd865rerhsd324nf!#%6dguewqweoiqw32032sd";
	
	public static final int SOCKS_PROXY_PORT = 8089;
	public static final int LOCAL_CONNECT_PORT = 8087;
	public static final int HTTPS_PROXY_PORT = 8443;
	
	public final String MEMORY_MANAGE_BEAN = "MemoryManager:op=control";
	public final String SUCCESS = "ok";
	
}