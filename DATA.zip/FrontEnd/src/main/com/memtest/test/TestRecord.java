package com.memtest.test;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.memtest.util.Utils;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


public class TestRecord {
	private String id;
	private String scriptName;              
	private List<MemoryState> memoryStates; // 内存状态
	private Date startTime;
	private Date endTime;
	
	private Double predictedBloatLiklyhood;     // 内存膨胀可疑度，权重
	private String manuallyAssignedLikelyhood;  //手工设置的可疑度

	public TestRecord(String id, List<MemoryState> memoryStates, Date startTime, Date endTime) {
		this.id = id;
		this.memoryStates = memoryStates;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public static String createID() {
		return Utils.createID("record_");
	}

	public JSONObject toFileJSON() {

		JSONObject json = new JSONObject();
		json.put("id", getId());
		json.put("bw", getBloatWeight());//bolatWeight
		json.put("st", Utils.dateTime2String(getStartTime()));//startTime
		json.put("et", Utils.dateTime2String(getEndTime()));//endtime
		 
		String ms = "{"+toString()+"}";
		json.put("ms",ms);//memoryStates
		json.put("sn", getScriptName());//ScriptName

		return json;
	}
	
	public JSONObject toPredictJSON() {
		JSONObject json = new JSONObject();
		json.put("script", getScriptName());
		json.put("newObject", getLastMemoryState().getAllocatedObjectCount());
		json.put("newArray", getLastMemoryState().getAllocatedArrayCount());
		json.put("freeObject", getLastMemoryState().getFreedObjectCount());
		json.put("fieldModify", getLastMemoryState().getFieldModifiedCount());
		json.put("openMethod", getLastMemoryState().getOpenMethodCount());
		json.put("closeMethod", getLastMemoryState().getCloseMethodCount());
		json.put("elapsedTime", getElapsedTime());
		json.put("image", getLastMemoryState().getImageMethodCount());
		return json;
	}

	public Date getEndTime() {
		return endTime;
	}

	public Date getStartTime() {
		return startTime;
	}
	
	public static List<MemoryState> toMemoryStates(String memoryStates){ 
		if(memoryStates.equals("{}") || memoryStates.equals("\"{}\"")){
			return new ArrayList<MemoryState>();
		} 
 
		String states = memoryStates.substring(2, memoryStates.length()-2);
		String[] data =states.split(";");
		List<MemoryState> out = new ArrayList<>();
		for(int i = 0;i<data.length;i++){
			MemoryState memoryState= MemoryState.fromJSON(data[i]);
			out.add(memoryState);
		}
		return out;
	}

	public static TestRecord fromFileJSON(JSONObject json) {
		List<MemoryState> memoryStates = TestRecord.toMemoryStates(json.getString("ms"));//memoryStates
		String id = json.getString("id");
		String scriptName = json.getString("sn");
		Double leakWeight = json.getDouble("bw");//bloatWeight
		Date startTime = null;
		Date endTime = null;

		try {			
			startTime = Utils.string2DateTime(json.getString("st"));//startTime
			endTime = Utils.string2DateTime(json.getString("et"));//endTime
		} catch (ParseException e) {
			e.printStackTrace();
		}

		TestRecord record = new TestRecord(id, memoryStates, startTime, endTime);
		record.scriptName = scriptName;

		record.setBloatWeight(leakWeight);
		return record;
	}
	

	public long getElapsedTime() {
		return (endTime.getTime() - startTime.getTime());
	}
	
	public List<MemoryState> getMemoryStates(){
		return memoryStates;
	}

	public String toString() {
		StringBuffer strmemoryState  = new StringBuffer();
		for(int i = 0;i<memoryStates.size();i++){
			MemoryState state = memoryStates.get(i);
			String strMS = state.toString();
			if(i<memoryStates.size()-1)
				strmemoryState.append(strMS+";");
			else
				strmemoryState.append(strMS);
		}
		
		return strmemoryState.toString() ;
	}
	
	public MemoryState getLastMemoryState(){
		return memoryStates.get(memoryStates.size()-1);
	}

	public void setMemoryStates(List<MemoryState> memoryStates) {
		this.memoryStates = memoryStates;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public long getPeakMemory() {
		long peak = 0;
		JSONArray array = null;
		if (memoryStates instanceof JSONArray) {
			array = (JSONArray) memoryStates;//
			for (int i = 0; i < memoryStates.size(); i++) {
				JSONObject s = (JSONObject) array.get(i);
				long used = s.getLong("um");
				if (used > peak) {
					peak = used;
				}
			}
		}else{
			for (int i = 0; i < memoryStates.size(); i++) {
				MemoryState state = memoryStates.get(i);
				long used = state.getUsedMemory();
				if (used > peak) {
					peak = used;
				}
			}
		}
		return peak;
	}
	
	public Double getBloatWeight() {
		return predictedBloatLiklyhood;
	}

	public void setBloatWeight(Double leakWeight) {
		this.predictedBloatLiklyhood = leakWeight;
	}

	public String getScriptName() {
		return scriptName;
	}

	public void setScriptName(String scriptName) {
		this.scriptName = scriptName;
	}

	public void setStartTime(Date start) {
		this.startTime = start;

	}

	public String getManualScore() {
		return manuallyAssignedLikelyhood;
	}

	public void setManualScore(String manualScore) {
		this.manuallyAssignedLikelyhood = manualScore;
	}

}
