package com.memtest.test;

import java.util.List;

public interface StatusNotifier {
	public void notify(String tag, Object o);
	public void notifyMonitors(List<?> monitors);
}
