package com.memtest.test;
 
import java.util.Date;
import java.util.List;
 

public class MemoryConsumptionMonitor extends ContainerMonitor {  
	private List<MemoryState> memoryStates;
	private boolean doDeepProfiling;
	private boolean gcAtBegining;
	
	public MemoryConsumptionMonitor(JmxWebContainerConnector jmx, StatusNotifier updater, 
			List<MemoryState> memoryStates, boolean doDeepProfiling, boolean gcAtBegining) { 
		super(jmx, updater);
		
		this.memoryStates = memoryStates; 
		this.doDeepProfiling = doDeepProfiling;
		this.gcAtBegining = gcAtBegining; 
	}

	@Override
	public void run() {
		try {			
	        long start = new Date().getTime();
	        
	        if(this.gcAtBegining){
	        	 jmx.forceGC();
	        	 Thread.sleep(2000);
	        }
	       
	        // 获得总内存 
			long total = jmx.getTotalPhysicalMemorySize(); 
			jmx.startProfiling(!doDeepProfiling); 
			
			guiNotifyAll("total", total);
			 
			
			while (!monitorStop) { 
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {  
					e.printStackTrace();
				}		
			 
				Date now = new Date();
				long timePoint = now.getTime() - start;		
				
				MemoryState state = jmx.getMemoryState();
				state.setTimePoint(timePoint);
				memoryStates.add(state);  
				
				guiNotifyAll("memoryState", state); 
			}
			
			jmx.stopProfiling();
		} catch (Exception e1) {
			System.err.println("Error: " + e1.getMessage());
		}
	} 
}