package com.memtest.test;

import java.util.ArrayList; 
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 记录各个类型上的内存使用统计
 */
public class TypeMemoryStat {
	public static class Stat{
		public String type;                // 类型
		public String context;
		
		public long newObjectCount;        // 分配对象数量
		public long freedObjectCount;      // 释放对象数量 
		public long accessedObjectCount;   // 访问对象数量
		public long occupiedMemorySize;    // 分配对象的总内存大小
		public double percent;
		public long increaseRate;          // 内存增长率
		
		public long aliveObjects(){
			return newObjectCount - freedObjectCount;
		}
	}
	
	public static class StatTree{
		public String name;
		public List<StatTree> subStates;
		public Stat total;
		public boolean isType;
		
		public String toString(){
			return name;
		}
	}

	private List<Stat> stats;  
	
	public TypeMemoryStat(int size) { 
		stats = new ArrayList<Stat>(size);
	} 
	
	public List<Stat> getTypeStats(){
		return stats;
	}
	
	public long calcMaxTypeMemorySize(){
		long max = 0;
		for(Stat s: stats){
			if(s.occupiedMemorySize > max){
				max = s.occupiedMemorySize;
			}
		}
		
		return max;
	}
	
	public void sortByMemoryConsumption(){  
		sortByMemoryConsumption(stats, true); 
		Stat total = sum(stats);
		for(Stat s: stats){
			s.percent = (double)s.occupiedMemorySize/ total.occupiedMemorySize;
		}
	}
	
	public static void sortByMemoryConsumption(List<Stat> stats, boolean descend){ 
		Collections.sort(stats, new Comparator<Stat>(){ 
			@Override
			public int compare(Stat o1, Stat o2) {
				int result = 0;
				if(o1.occupiedMemorySize < o2.occupiedMemorySize){
					result = 1;
				}
				else if(o1.occupiedMemorySize > o2.occupiedMemorySize){
					result = -1;
				}
				else{
					result = 0;
				}
				
				return descend? result: (-result);
			}			
		});
	}
	
	public static void sortByAliveObjects(List<Stat> stats, boolean descend){ 
		Collections.sort(stats, new Comparator<Stat>(){ 
			@Override
			public int compare(Stat o1, Stat o2) {
				int result = 0;
				if(o1.aliveObjects() < o2.aliveObjects()){
					result = 1;
				}
				else if(o1.aliveObjects() > o2.aliveObjects()){
					result = -1;
				}
				else{
					result = 0;
				}
				
				return descend? result: (-result);
			}			
		});
	}
	
	public static void sortByMemoryIncreaseRate(List<Stat> stats, boolean descend){ 
		Collections.sort(stats, new Comparator<Stat>(){ 
			@Override
			public int compare(Stat o1, Stat o2) {
				int result = 0;
				if(o1.increaseRate < o2.increaseRate){
					result = 1;
				}
				else if(o1.increaseRate > o2.increaseRate){
					result = -1;
				}
				else{
					result = 0;
				}
				
				return descend? result: (-result);
			}			
		});
	}
	
	public static Stat fromJSONToStat(JSONObject json) {
		Stat s = new Stat();
		s.type = json.getString("T");
		s.context = (String)json.get("C");
		s.newObjectCount = json.getLong("NC");
		s.freedObjectCount = json.getLong("FC");
		s.accessedObjectCount = json.getLong("AC");
		s.occupiedMemorySize = json.getLong("MS");    
		
		return s;
	}
	 
	public static TypeMemoryStat fromJSON(String json) {
		JSONArray array = JSONArray.fromObject(json);		
		int length = array.size();
		
		TypeMemoryStat tstate = new TypeMemoryStat(length);
		for(int i=0; i<length; i++){
			JSONObject obj = (JSONObject)array.get(i);
			Stat stat = fromJSONToStat(obj);
			tstate.stats.add(stat);
		} 

		return tstate;
	}
	
	public List<StatTree> toStatTree(){
		Map<String, List<Stat>> typeToStats = new HashMap<String, List<Stat>>();
		for(Stat s: stats){
			String type = s.type;
			List<Stat> stats = typeToStats.get(type);
			if(stats==null){
				stats = new ArrayList<Stat>();
				typeToStats.put(type, stats);
			}
			
			stats.add(s);
		}
		
		List<StatTree> roots = new ArrayList<StatTree>(typeToStats.size());
		for(Map.Entry<String, List<Stat>> e: typeToStats.entrySet()){
			List<Stat> substats = e.getValue();
			StatTree tree = new StatTree();
			tree.name = e.getKey();
			tree.isType = true;
			tree.total = sum(substats);
			tree.subStates = toStatTree(substats, "");
			if(tree.subStates.size()==1){
				if(tree.subStates.get(0).name.length()==0){
					tree.subStates = Collections.emptyList();
				}
			}
			
			roots.add(tree);
		}
		
		sortStatTreeByMemoryConsumption(roots);
		return roots;		
	}
	
	public static List<StatTree> toStatTree(List<Stat> stats, String contextPrefix){
		Map<String, List<Stat>> methodToStats = new HashMap<String, List<Stat>>();
		for(Stat s: stats){
			String context = s.context;
			String method = null;
			if(context==null){
				method = "";
			}
			else if(context.length()<=contextPrefix.length()){
				method = "";
			}
			else{ 
				context = context.substring(contextPrefix.length());
				String[] splits = context.split(";");
				if(splits.length>0){
					method = splits[0];
				}
				else{
					method = "";
				}
			} 
			
			List<Stat> substats = methodToStats.get(method);
			if(substats==null){
				substats = new ArrayList<Stat>();
				methodToStats.put(method, substats);
			}
			
			substats.add(s);
		}
		
		List<StatTree> roots = new ArrayList<StatTree>(methodToStats.size());
		for(Map.Entry<String, List<Stat>> e: methodToStats.entrySet()){
			List<Stat> substats = e.getValue();
			String method = e.getKey();
			StatTree tree = new StatTree();
			tree.name = method;
			tree.total = sum(substats);
			
			if(method.length()>0){
				String newContextPrefix = contextPrefix.length()==0? method + ";" : contextPrefix + method + ";";
				tree.subStates = toStatTree(substats, newContextPrefix);	
				if(tree.subStates.size()==1){
					if(tree.subStates.get(0).name.length()==0){
						tree.subStates = Collections.emptyList();
					}
				}
			}
			else{
				tree.subStates = Collections.emptyList();
			}
			
			roots.add(tree);
		}
		
		sortStatTreeByMemoryConsumption(roots);
		return roots;	
	}
	
	public static void sortStatTreeByMemoryConsumption(List<StatTree> roots){ 
		sortStatTreeByMemoryConsumption(roots, true); 
		Stat total = sumForStatTrees(roots);
		for(StatTree s: roots){
			s.total.percent = (double)s.total.occupiedMemorySize/ total.occupiedMemorySize;
		}
	}
	
	public static void sortStatTreeByMemoryConsumption(List<StatTree> roots, boolean descend){ 
		Collections.sort(roots, new Comparator<StatTree>(){ 
			@Override
			public int compare(StatTree o1, StatTree o2) {
				int result = 0;
				if(o1.total.occupiedMemorySize < o2.total.occupiedMemorySize){
					result = 1;
				}
				else if(o1.total.occupiedMemorySize > o2.total.occupiedMemorySize){
					result = -1;
				}
				else{
					result = 0;
				}
				
				return descend? result: (-result);
			} 
		}); 
	} 
	
	public static void sortStatTreeByAliveObjects(List<StatTree> roots, boolean descend){ 
		Collections.sort(roots, new Comparator<StatTree>(){ 
			@Override
			public int compare(StatTree o1, StatTree o2) {
				int result = 0;
				if(o1.total.aliveObjects() < o2.total.aliveObjects()){
					result = 1;
				}
				else if(o1.total.aliveObjects() > o2.total.aliveObjects()){
					result = -1;
				}
				else{
					result = 0;
				}
				
				return descend? result: (-result);
			} 
		}); 
	} 
	
	public static void sortStatTreeByMemoryIncreaseRate(List<StatTree> roots, boolean descend){ 
		Collections.sort(roots, new Comparator<StatTree>(){ 
			@Override
			public int compare(StatTree o1, StatTree o2) {
				int result = 0;
				if(o1.total.increaseRate < o2.total.increaseRate){
					result = 1;
				}
				else if(o1.total.increaseRate > o2.total.increaseRate){
					result = -1;
				}
				else{
					result = 0;
				}
				
				return descend? result: (-result);
			} 
		}); 
	} 
	
	
	private static Stat sumForStatTrees(List<StatTree> stats){
		Stat s = new Stat(); 
		for(StatTree st: stats){
			s.newObjectCount += st.total.newObjectCount;
			s.freedObjectCount += st.total.freedObjectCount;
			s.accessedObjectCount += st.total.accessedObjectCount;
			s.occupiedMemorySize += st.total.occupiedMemorySize;
		}
		
		return s;
	}
	
	
	private static Stat sum(List<Stat> stats){
		Stat s = new Stat(); 
		for(Stat st: stats){
			s.newObjectCount += st.newObjectCount;
			s.freedObjectCount += st.freedObjectCount;
			s.accessedObjectCount += st.accessedObjectCount;
			s.occupiedMemorySize += st.occupiedMemorySize;
		}
		
		return s;
	}
}
