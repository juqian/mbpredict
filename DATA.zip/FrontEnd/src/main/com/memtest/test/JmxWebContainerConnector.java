package com.memtest.test;


import javax.management.MBeanServerConnection;
import javax.management.ObjectName; 
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import com.memtest.Constants;

/**
 * 该类封装所有JXM通讯
 * 
 * 请不要把JMX通信散落在各处
 *
 */
public class JmxWebContainerConnector {
	private MBeanServerConnection mbsc;
	private ObjectName mbeanName;

	public JmxWebContainerConnector() throws Exception {
		try {
			int serverPort = Constants.MONITOR_SERVANT_PORT;
			JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://localhost:" + serverPort + "/jmxrmi");
			JMXConnector jmxc = JMXConnectorFactory.connect(url, null);

			this.mbsc = jmxc.getMBeanServerConnection();
			this.mbeanName = new ObjectName(Constants.MEMORY_MANAGE_BEAN);
		} catch (Exception e) {
			System.err.println("。。。。连接服务器失败。。。。");
			throw new Exception(e);
		}
	}

	public long getTotalPhysicalMemorySize() throws Exception {
		int mask = 1;
		Long total = (Long) mbsc.invoke(mbeanName, "getTotalPhysicalMemorySize", new Object[] { mask },
				new String[] { "int" });
		return total;
	}

	public void startProfiling(boolean isLightWeight) throws Exception { 
		mbsc.invoke(mbeanName, "startProfiling", new Object[] { isLightWeight }, new String[] { "boolean" });
	}
	
	public void stopProfiling() throws Exception {  
		mbsc.invoke(mbeanName, "stopProfiling", new Object[] {  }, new String[] { });
	}

	public void forceGC() throws Exception {  
		mbsc.invoke(mbeanName, "forceGC", new Object[] { }, new String[] { });
	}
	
	public MemoryState getMemoryState() throws Exception {
		int overallMemoryUseMask = 1;
		String json = (String) mbsc.invoke(mbeanName, "getMemoryState", 
				new Object[] { overallMemoryUseMask }, new String[] { "int" });
		MemoryState state = MemoryState.fromJmxJSON(json);
		return state;
	}
	
	public TypeMemoryStat getTypeMemoryStat(boolean useContextDistinguishedTypeStat) throws Exception {
		int typeMemoryUseOption = 3;
		if(useContextDistinguishedTypeStat){
			typeMemoryUseOption = 5;
		}
		String json = (String) mbsc.invoke(mbeanName, "getMemoryState", 
				new Object[] { typeMemoryUseOption }, new String[] { "int" }); 
		
		TypeMemoryStat state = TypeMemoryStat.fromJSON(json);
		return state;
	}
	 
	public TypeMemoryStat statOwnedMemory(boolean contextDistinguished) throws Exception{ 
		String json = (String) mbsc.invoke(mbeanName, "statOwnedMemory", 
				new Object[] { contextDistinguished }, new String[] { "boolean" }); 
		
		TypeMemoryStat state = TypeMemoryStat.fromJSON(json);
		return state;
	}

	public boolean startSpecificationTesting(String testSessionId, byte[] specTestPackage) throws Exception {
		boolean bOK = (boolean) mbsc.invoke(mbeanName, "startSpecificationTesting", 
				new Object[] { testSessionId, specTestPackage },
				new String[] { "java.lang.String", "[B" });
		return bOK;
	}
	
	public void stopSpecificationTesting(String testSessionID) throws Exception {
		mbsc.invoke(mbeanName, "stopSpecificationTesting", new Object[] { testSessionID }, 
				new String[] { "java.lang.String" }); 
	}	 

	public void setupLoadtimeWeaving(String contextPath, String warName, byte[] zippedUpdateData) throws Exception{
		mbsc.invoke(mbeanName, "setupLoadtimeWeaving", 
				new Object[] { contextPath, warName,  zippedUpdateData},
				new String[] { "java.lang.String", "java.lang.String", "[B" }); 
	}
	
	public void tearDownLoadtimeWeaving(String contextPath, String contextWarFolderName) throws Exception{
		mbsc.invoke(mbeanName, "tearDownLoadtimeWeaving", 
				new Object[] { contextPath, contextWarFolderName},
				new String[] { "java.lang.String", "java.lang.String"});  
	}
}
