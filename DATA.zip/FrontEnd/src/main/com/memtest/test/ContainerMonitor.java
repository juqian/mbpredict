package com.memtest.test;

import java.util.Collections;
import java.util.List;
 

public abstract class ContainerMonitor implements Runnable {  
	protected volatile boolean monitorStop;
	protected JmxWebContainerConnector jmx; 
	protected List<StatusNotifier> updaters;

	public ContainerMonitor(JmxWebContainerConnector jmx, List<StatusNotifier> updaters) {
		this.jmx = jmx;
		this.updaters = updaters; 
	} 
	
	public ContainerMonitor(JmxWebContainerConnector jmx, StatusNotifier updater) {
		this.jmx = jmx;
		this.updaters = Collections.singletonList(updater); 
	} 
 
	protected void guiNotifyAll(String messageTag, Object data){
		ContainerMonitor.this.notifyAll(messageTag, data); 
	}
	
	protected void notifyAll(String messageTag, Object data){
		for(StatusNotifier updater: updaters){
			if(updater==null) continue;
			
			updater.notify(messageTag, data); 
		}
	}
	
	public void stop(){
		monitorStop = true;
	}
}