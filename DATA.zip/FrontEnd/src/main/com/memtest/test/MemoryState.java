package com.memtest.test;


import net.sf.json.JSONObject;

/**
 * 
 * 每个时间点上的内存记录
 *
 */
public class MemoryState {
	

	private long timePoint;
	private long usedMemory;
	private int allocatedObjectCount;
	private int freedObjectCount;
	private int allocatedArrayCount;
	private int freedArrayCount;
	private int fieldModifiedCount;

	private int openMethodCount;
	private int closeMethodCount;
	private int imageMethodCount;
	
	//private int gcTimes;
	public void setAllocatedObjectCount(int allocatedObjectCount) {
		this.allocatedObjectCount = allocatedObjectCount;
	}

	public void setFreedObjectCount(int freedObjectCount) {
		this.freedObjectCount = freedObjectCount;
	}

	public void setAllocatedArrayCount(int allocatedArrayCount) {
		this.allocatedArrayCount = allocatedArrayCount;
	}

	public void setFreedArrayCount(int freedArrayCount) {
		this.freedArrayCount = freedArrayCount;
	}

	public void setFieldModifiedCount(int fieldModifiedCount) {
		this.fieldModifiedCount = fieldModifiedCount;
	}

	public void setOpenMethodCount(int openMethodCount) {
		this.openMethodCount = openMethodCount;
	}

	public void setCloseMethodCount(int closeMethodCount) {
		this.closeMethodCount = closeMethodCount;
	}

	public void setImageMethodCount(int imageMethodCount) {
		this.imageMethodCount = imageMethodCount;
	}
	public MemoryState(long usedMemory) {
		this.usedMemory = usedMemory;
	}
	
	public void setUsedMemory(long usedMemory){
		this.usedMemory = usedMemory;
	}

	public int getAllocatedObjectCount() {
		return allocatedObjectCount;
	}

	public int getFreedObjectCount() {
		return freedObjectCount;
	}

	public int getAllocatedArrayCount() {
		return allocatedArrayCount;
	}

	public int getFreedArrayCount() {
		return freedArrayCount;
	}

	public long getTimePoint() {
		return timePoint;
	}

	public long getUsedMemory() {
		return usedMemory;
	}

	public int getFieldModifiedCount() {
		return fieldModifiedCount;
	}

	public int getOpenMethodCount() {
		return openMethodCount;
	}

	public int getCloseMethodCount() {
		return closeMethodCount;
	}
	
	public int getImageMethodCount() {
		return imageMethodCount;
	}
	
	//public int getGCTimes(){
	//	return gcTimes;
	//}

	public void setTimePoint(long timePoint) {
		this.timePoint = timePoint;
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("um", getUsedMemory());//usedMemory
		json.put("tp", getTimePoint());//timePoint
		json.put("ao", getAllocatedObjectCount());//allocatedObjectCount
		json.put("fo", getFreedObjectCount());//freedObjectCount
		json.put("aa", getAllocatedArrayCount());//allocatedArrayCount
		json.put("fa", getFreedArrayCount());//freedArrayCount
		json.put("fm", getFieldModifiedCount());//fieldModifiedCount
		json.put("om", getOpenMethodCount());//openMethodCount
		json.put("cm", getCloseMethodCount());//closeMethodCount
		json.put("im", getImageMethodCount());//imageMethodCount

		return json;
	}

	public static MemoryState fromJSON(String json) {
		JSONObject jobj = JSONObject.fromObject(json);
		long tp = jobj.getLong("tp");
		MemoryState state = fromJmxJSON(json);
		state.setTimePoint(tp);
		return state;
	}
	
	public static MemoryState fromJmxJSON(String json) {
		JSONObject jobj = JSONObject.fromObject(json);
		long usedMemory = jobj.getLong("um");
		
		int ao = jobj.getInt("ao");
		int fo = jobj.getInt("fo");
		int aa = jobj.getInt("aa");
		int fa = jobj.getInt("fa");
		int fm = jobj.getInt("fm");
		int om = jobj.getInt("om");
		int cm = jobj.getInt("cm");
		int im = jobj.getInt("im");

		MemoryState state = new MemoryState(usedMemory);
		
		state.freedArrayCount = fa;
		state.freedObjectCount = fo;
		state.allocatedArrayCount = aa;
		state.allocatedObjectCount = ao;
		state.fieldModifiedCount = fm;
		state.openMethodCount = om;
		state.closeMethodCount = cm;
		state.imageMethodCount = im;
 
		return state;
	}
	
	@Override
	public String toString() {
		 String state = "{um:"+ getUsedMemory()//usedMemory
				 +", tp:"+ getTimePoint()
		 		 +", ao:"+ getAllocatedObjectCount()
				 +", fo:"+ getFreedObjectCount()
				 +", aa:"+ getAllocatedArrayCount()
				 +", fa:"+ getFreedArrayCount()
				 +", fm:"+ getFieldModifiedCount()
				 +", om:"+getOpenMethodCount()
				 +", cm:"+getCloseMethodCount()
				 +", im:"+getImageMethodCount()
				 +"}";
		return state;
	}
	
	

}
