package com.memtest;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;


/**
 * configurable options 
 */
public class Options {
	String defaultContainerLocation;
	String tomcatAgentDLL;
	String hookerPath;
	
	boolean debug = false;
	boolean loadtimeWeaving = false;
	boolean tomcatRemoteDebug = false;

	public Options(InputStream configSource) throws Exception{
	     DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	     Document document = builder.parse(configSource);
	     XPath xpath = XPathFactory.newInstance().newXPath();   
	 	 
	 	 defaultContainerLocation = getXpathText(document, xpath, "/config/default_container"); 	 	
	 	 
	 	 tomcatAgentDLL = getXpathText(document, xpath, "/config/tomcat_agent_dll"); 
	 	 hookerPath = getXpathText(document, xpath, "/config/hooker_path"); 
	 	
	 	 debug = "true".equals(getXpathText(document, xpath, "/config/debug")) ; 
	 	 loadtimeWeaving = "true".equals(getXpathText(document, xpath, "/config/loadtime_weaving")) ;
	 	 tomcatRemoteDebug = "true".equals(getXpathText(document, xpath, "/config/tomcat_remote_debug")) ;
	}

	
	public boolean isDebug(){
		return debug;
	}

	protected String getXpathAttribute(Document document, XPath xpath,	String xpathExpression) throws XPathExpressionException {
		Node node = (Node) xpath.evaluate(xpathExpression, document, XPathConstants.NODE);
		return node.getNodeValue();
	}
	
	protected String getXpathText(Document document, XPath xpath,	String xpathExpression) throws XPathExpressionException {
		Node node = (Node) xpath.evaluate(xpathExpression, document, XPathConstants.NODE);
		return node.getTextContent();
	} 
 
	
	public String getTomcatAgentDLL(){ 
		try {
			File file = new File(tomcatAgentDLL);
			return file.getCanonicalPath();
		} catch (IOException e) { 
			e.printStackTrace();
		}
		
		return null;
	}
	
	public String getHookerPath(){ 
		try {
			return new File(hookerPath).getCanonicalPath();
		} catch (IOException e) { 
			e.printStackTrace();
		}
		
		return null;
	}

	public String getDefaultContainerLocation(){ 
		try {
			File file = new File(defaultContainerLocation);
			return file.getCanonicalPath();
		} catch (IOException e) { 
			e.printStackTrace();
		}
		
		return null;
	}
	
	public boolean isLoadtimeWeaving(){
		return loadtimeWeaving;
	}
	
	public boolean isTomcatRemoteDebuggingEnabled(){
		return this.tomcatRemoteDebug;
	}
}
