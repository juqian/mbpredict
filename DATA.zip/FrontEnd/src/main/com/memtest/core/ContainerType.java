package com.memtest.core;

public enum ContainerType {
	Tomcat, WebLogic, Default, Unknown
}
