package com.memtest.core;

import java.io.File;

/**
 *  
 *
 */
public class TestScript implements Cloneable{
	private File scriptFile;
	
	public TestScript(File file) {
		this.scriptFile = file; 
	}
	
	public File getScriptFile(){
		return scriptFile;
	}  
	
	public String toString(){
		return scriptFile.toString();
	} 

	public void rename(String newName){
		File newScript = new File(scriptFile.getParent(), newName);
		scriptFile.renameTo(newScript);
		scriptFile = newScript;
	}
 
 
	public String getPrefixName() { 
		String name = scriptFile.getName();
		return name.substring(0,name.length()-3);
	}
	
	public String getName() { 
		return scriptFile.getName();
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		TestScript script = new TestScript(scriptFile);
		return script;
	}
}
