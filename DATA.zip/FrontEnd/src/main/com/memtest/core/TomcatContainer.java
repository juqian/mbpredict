package com.memtest.core;
 
import java.io.File;
import java.io.FileFilter;
import java.io.IOException; 
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.memtest.Global;
import com.memtest.Options;
import com.memtest.util.CmdRunner;
import com.memtest.util.Utils;
import com.thoughtworks.xstream.core.util.Base64Encoder; 

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpConnection; 
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part; 
import org.apache.commons.io.FilenameUtils;  


public class TomcatContainer implements WebContainer{
	public final static String DEFAULT_ADMIN_USER = "tomcat";
	public final static String DEFAULT_ADMIN_PASSWORD = "123";
	
	private ContainerType type;
	private String hostURL;
	private File location;

	private static Map<File, TomcatContainer> activeContainers = Collections.synchronizedMap(new HashMap<File, TomcatContainer>());
	
	public TomcatContainer(ContainerType type, String hostURL, File location){
		this.type = type;
		this.location = location;
		this.hostURL = hostURL;
	}
	
	public TomcatContainer(String hostURL, File location){
		this(ContainerType.Tomcat, hostURL, location);
	}
	
	public boolean startContainer() { 
		if(location==null || !location.exists()){
			return false;
		}
		
		// 如果容器当前活跃，则不用再启动
		if(activeContainers.get(location)!=null){
			return true;
		}		
		
		TomcatContainer old = activeContainers.put(location, this);
		
		Thread thread = new Thread(){
			public void run() {   
				
				boolean loadtimeWeaving = Global.v().getOptions().isLoadtimeWeaving();
				startTomcat(location.toString(), loadtimeWeaving);
				
				activeContainers.remove(location);
			}
		};
		
		thread.start();
		if(old==null){
			try {
				Thread.sleep(30* 1000);
			} catch (InterruptedException e) {  
			}
		} 
		
		return true;
	}
	
	
	
	public static void startTomcat(String tomcatHome, boolean loadtimeWeaving){
		//startTomcatFromBAT(tomcatHome);
		startTomcatFromJavaCmd(tomcatHome, loadtimeWeaving);
	}

	/**
	 * 通过startup.bat脚本调用catalina.bat启动
	 * 这种方式的一个不足是无法知道进程何时结束，因为 BAT 中用start命令启动Java，
	 * 这时Process.waitFor()只监控到BAT结束，而不是Java进程结束
	 * 
	 */
	protected static void startTomcatFromBAT(String tomcatHome){
		String configPath = tomcatHome + "\\test\\config.xml"; 
		try {
			writeConfigFile(tomcatHome, configPath);
		} catch (IOException e) { 
			e.printStackTrace();
		} 
		
		Options options = Global.v().getOptions();
		String agentDLL  = options.getTomcatAgentDLL();
		String cmdPath = tomcatHome.toString() + "\\bin\\startup.bat";				 
		 
		String hookerPath = options.getHookerPath(); 
		String jvmOpt = "-agentpath:\"" + agentDLL  + "=" + configPath +"\""  
		                + " -Xbootclasspath/p:" + hookerPath  + " -noverify ";  
		
		String javaHome = System.getProperty("java.home");	 
		Map<String,String> env = new HashMap<String,String>();
		env.put("JAVA_OPTS", jvmOpt);
		env.put("JAVA_HOME", javaHome); 

		String dir = tomcatHome;
		CmdRunner.runCommand(dir, env, Collections.singletonList(cmdPath), true);
	}
	
	private static void startTomcatFromJavaCmd(String tomcatHome, boolean loadtimeWeaving){
		String configPath = tomcatHome + "\\test\\config.xml"; 
		try {
			writeConfigFile(tomcatHome, configPath);
		} catch (IOException e) { 
			e.printStackTrace();
		} 
		
		Options options = Global.v().getOptions();
		String agentDLL  = options.getTomcatAgentDLL();
		String jreHome = System.getProperty("java.home");	
		String hookerPath = options.getHookerPath(); 
		
		String javaBin = "\"" + jreHome + "\\bin\\java.exe\"";	
		String cmdline = javaBin + " -agentpath:\"" + agentDLL  + "\"=\"" + configPath +"\""  
	             + " -Xbootclasspath/p:\"" + hookerPath  + "\" -noverify"
	             + " -Djava.util.logging.config.file=\"" + tomcatHome + "\\conf\\logging.properties\""
	             + " -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager"
	             + " -Djava.endorsed.dirs=\"" + tomcatHome + "\\endorsed\""
	             + " -classpath \"" + tomcatHome + "\\bin\\bootstrap.jar\";\""
	                           + tomcatHome + "\\bin\\tomcat-juli.jar\""
	             + " -Dcatalina.base=\"" + tomcatHome + "\""
	             + " -Dcatalina.home=\"" + tomcatHome + "\""
	             + " -Djava.io.tmpdir=\"" + tomcatHome + "\\temp\""  
	             + " org.apache.catalina.startup.Bootstrap start";  
		cmdline.hashCode();
		
		List<String> cmdlineArgs = new ArrayList<String>();
		cmdlineArgs.add("cmd");
		cmdlineArgs.add("/c");
		cmdlineArgs.add("start");
		cmdlineArgs.add("/wait");
		cmdlineArgs.add("\"Tomcat\"");
		cmdlineArgs.add(javaBin);
		
		if(options.isTomcatRemoteDebuggingEnabled()){
			//-Xdebug -Xrunjdwp:transport=dt_socket,address=127.0.0.1:8888,server=y,suspend=n
			cmdlineArgs.add("-Xdebug");
			cmdlineArgs.add("-Xrunjdwp:transport=dt_socket,address=127.0.0.1:8888,server=y,suspend=n");
		}
		
		if(loadtimeWeaving){
			String weaver = Global.v().getWeaverAgent();
			cmdlineArgs.add("-javaagent:\"" + weaver  + "\"");
		}
		
		cmdlineArgs.add("-agentpath:\"" + agentDLL  + "\"=\"" + configPath +"\"");
		cmdlineArgs.add("-Xbootclasspath/p:\"" + hookerPath  + "\"");
		cmdlineArgs.add("-noverify");
		cmdlineArgs.add("-Djava.util.logging.config.file=\"" + tomcatHome + "\\conf\\logging.properties\"");
		cmdlineArgs.add("-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager");
		cmdlineArgs.add("-Djava.endorsed.dirs=\"" + tomcatHome + "\\endorsed\"");
		cmdlineArgs.add("-classpath");
		cmdlineArgs.add("\"" + tomcatHome + "\\bin\\bootstrap.jar\";\"" + tomcatHome + "\\bin\\tomcat-juli.jar\"");
		cmdlineArgs.add("-Dcatalina.base=\"" + tomcatHome + "\"");
		cmdlineArgs.add("-Dcatalina.home=\"" + tomcatHome + "\"");
		cmdlineArgs.add("-Djava.io.tmpdir=\"" + tomcatHome + "\\temp\"");
		cmdlineArgs.add("org.apache.catalina.startup.Bootstrap");
		cmdlineArgs.add("start");
		
		Map<String,String> env = new HashMap<String,String>(); 
		String dir = tomcatHome;
		CmdRunner.runCommand(dir, env, cmdlineArgs, true, false);
	}	           
	  
	@Override
	public ContainerType getType() { 
		return type;
	}

	@Override
	public File getLocation() { 
		return location;
	}
	
	private static void writeConfigFile(String tomcatHome, String configFile) throws IOException{
		String out = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
		out += "\n\n<config>";
		
		out += "\n\n<classpath>"; 
		
		File f = new File("..");
		String programHome = f.getCanonicalPath();
		String p1 = programHome + "/Monitor/bin/"; 
		String p2 = programHome + "/Monitor/lib/log4j-1.2.17.jar";
		String p3 = tomcatHome + "/bin/bootstrap.jar";
		String p4 = tomcatHome + "/bin/tomcat-juli.jar";
		String p5 = tomcatHome + "/lib/catalina.jar"; 
		String p6 = programHome + "/Monitor/lib/asm/asm-all-5.1.jar"; 
		String p7 = programHome + "/Monitor/lib/commons-io-2.0.1.jar"; 
		String classpath = "\n  " + p1  + ";"
				         + "\n  " + p2  + ";"
				         + "\n  " + p3  + ";"
				         + "\n  " + p4  + ";"
				         + "\n  " + p5  + ";"
				         + "\n  " + p6  + ";"
				         + "\n  " + p7;
		classpath = classpath.replace('\\', '/');
		
		out += classpath;
		out += "\n</classpath>";
		
		out += "\n\n</config>";
		
		Utils.saveTextToFile(out, configFile);
	}
	
 
	public String deploy(File warFile) throws DeploymentException {
		String context = deploy(hostURL, "tomcat", "123", warFile);
		return context;
	}
 
	public boolean reload(String contextName) throws DeploymentException{
		return reload(hostURL, "tomcat", "123", contextName); 
	}
	
	static class NoPersistenceConnectionManager extends MultiThreadedHttpConnectionManager {
		@Override
		public void releaseConnection(HttpConnection conn) {
			super.releaseConnection(conn);
			conn.close();
		}
	} 
	
	/**
	 *  
	 * @see http://tomcat.apache.org/tomcat-6.0-doc/manager-howto.html
	 */
	public static String deploy(String tomcatHostURL, String adminUser, 
			String adminPassword, File warFile) throws DeploymentException {
		//curl -T "Test3-showcase-order.war" "http://tomcat:123@localhost:8080/manager/html/deploy?path=/Test3-showcase-order&update=true"
		//Tomcat v6: http://localhost:8080/manager/deploy?path=/foo 
		//Tomcat v7: http://localhost:8080/manager/html/deploy?path=/foo 
		// check WAR file
		String warFileName = warFile.getName();
		if (!warFile.exists()) {
			throw new DeploymentException(String.format("The archive location '%s' does not exist", warFile));
		}
		if (warFile.isDirectory()) {
			throw new DeploymentException(String.format("The archive location '%s' is a directory", warFile));
		}  

		if (!warFileName.endsWith(".war")) {
			throw new DeploymentException("Archive is not a WAR file " + warFile);
		} 
		
		String context = FilenameUtils.getBaseName(warFileName); 
		String deploymentURL = tomcatHostURL + "/manager/html/deploy?path=/" + context + "&update=true"; 
		
		HttpClient client = new HttpClient(new NoPersistenceConnectionManager()); 
		PutMethod method = new PutMethod(deploymentURL); 
		String adminAccount = adminUser + ":" + adminPassword;
		String encoding = new Base64Encoder().encode(adminAccount.getBytes()); 
		method.addRequestHeader("Authorization", "Basic " + encoding); 

		String responseBody;
		int statusCode = 0;
		try { 
			Part[] parts = {new FilePart(warFileName, warFile)};
			method.setRequestEntity(new MultipartRequestEntity(parts, method.getParams())); 
			
			client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);

			System.out.println("deploy war file: " + warFile); 
			
			statusCode = client.executeMethod(method);
			responseBody = method.getResponseBodyAsString();
		} catch (Exception e) {
			throw new DeploymentException("Problem contacting the Tomcat Server: "	+ e.getMessage(), e);
		} finally {
			method.releaseConnection(); 
		}

		if (isHttpErrorCode(statusCode)) {
			throw new DeploymentException("Tomcat Server reported a deployment Error: " + responseBody);
		} 
		
		//OK - Deployed application at context path /foo	
		String expectedMessage = "OK - Deployed application at context path /"+context;
		if(responseBody.contains(expectedMessage)){
			System.out.println(expectedMessage);
			return context;
		} 
		else{
			System.out.println(responseBody);
		}
		
		return null;
	}  
	
	public static boolean reload(String tomcatHostURL, String adminUser, String adminPassword, String contextPath)	
			throws DeploymentException {
		//Tomcat v6: http://localhost:8080/manager/undeploy?path=/examples
		//Tomcat v7: http://localhost:8080/manager/html/reload?path=/examples
		String reloadURL = tomcatHostURL + "/manager/html/reload?path=/" + contextPath;
		HttpClient client = new HttpClient(new NoPersistenceConnectionManager());
		HttpMethod method = new PostMethod(reloadURL); 
 
		String adminAccount = adminUser + ":" + adminPassword;
		String encoding = new Base64Encoder().encode(adminAccount.getBytes()); 
		method.addRequestHeader("Authorization", "Basic " + encoding); 
        
		System.out.println("reload " + contextPath); 

		int statusCode = 0;
		String responseBody = null;
		try {
			statusCode = client.executeMethod(method);
			responseBody = method.getResponseBodyAsString();
		} catch (Exception e) {
			throw new DeploymentException("Problem contacting the Tomcat Server: " + e.getMessage(), e);
		} finally {
			method.releaseConnection();
		}

		if(isHttpErrorCode(statusCode)) {
			throw new DeploymentException("Tomcat Server reported a reload Error: " + responseBody);
		}

		if(responseBody.contains("OK - Reloaded application at context path /" + contextPath)){
			return true;
		} 
		else{
			System.out.println(responseBody);
		}
		
		return false;
	} 
 
	
	public static boolean undeploy(String tomcatHostURL, String adminUser, String adminPassword, String contextPath)	
			throws DeploymentException {
		//Tomcat v6: http://localhost:8080/manager/undeploy?path=/examples
		//Tomcat v7: http://localhost:8080/manager/html/undeploy?path=/examples
		String undeployURL = tomcatHostURL + "/manager/html/undeploy?path=/" + contextPath;
		HttpClient client = new HttpClient(new NoPersistenceConnectionManager());
		HttpMethod method = new PostMethod(undeployURL); 
 
		String adminAccount = adminUser + ":" + adminPassword;
		String encoding = new Base64Encoder().encode(adminAccount.getBytes()); 
		method.addRequestHeader("Authorization", "Basic " + encoding); 
        
		System.out.println("undeploy " + contextPath); 

		int statusCode = 0;
		String responseBody = null;
		try {
			statusCode = client.executeMethod(method);
			responseBody = method.getResponseBodyAsString();
		} catch (Exception e) {
			throw new DeploymentException("Problem contacting the Tomcat Server: " + e.getMessage(), e);
		} finally {
			method.releaseConnection();
		}

		if(isHttpErrorCode(statusCode)) {
			throw new DeploymentException("Tomcat Server reported a undeployment Error: " + responseBody);
		}
		
		//OK - Undeployed application at context path /examples 
		if(responseBody.contains("OK - Undeployed application at context path /" + contextPath)){
			return true;
		} 
		else{
			System.out.println(responseBody);
		}
		
		return false;
	} 

	private static boolean isHttpErrorCode(int statusCode) {
		return statusCode < 200 || statusCode > 299;
	}
	

	
	public static File[] findDeployedWebAppFile() {
		String defaultTomcatPath = Global.v().getOptions().getDefaultContainerLocation();
		String webAppPath = defaultTomcatPath + "\\webapps";
		File file = new File(webAppPath);

		File[] subFiles = file.listFiles(new FileFilter() {
			@Override
			public boolean accept(File pathname) {
				String filename = pathname.getName();
				if (filename.contains("Test") && pathname.isDirectory()) {
					return true;
				} else {
					return false;
				}
			}
		});

		return subFiles;
	}
}
