package com.memtest.core;

import java.io.File;

public interface WebContainer {
	public static class DeploymentException extends Exception {
		private static final long serialVersionUID= -5810936363158504970L;

		public DeploymentException(String message) {
			super(message);
		}

		public DeploymentException(String string, Exception e) {
			super(string, e);
		}
	}
	
	public ContainerType getType();
	public File getLocation();
	public boolean startContainer();
	
	public String deploy(File warFile) throws DeploymentException;
	
	public boolean reload(String contextName) throws DeploymentException;
}
